package chess;

import java.util.ArrayList;
import java.util.Collections;

import pieces.Coordinate;
import pieces.Piece;
import static util.StringUtil.appendNewLine;

public class Board {
	// class variable
	public static final int BOARD_LINES = 8;
	private static final double POINTS_VERTICAL_PAWN = 0.5;
	
	// instance variable
	private ArrayList<Line> lines = new ArrayList<Line>(8);
	
	// instance method
	public void initialize () {		
		for (int i=0; i<Board.BOARD_LINES; i++)
			lines.add(Line.create());
	}
	
	public Line getLine(int index) {
		return lines.get(index);
	}
	
	public void setPiece(Piece piece, String code) {
		Coordinate coordinateOfPiece = Coordinate.create(code);
		int x = coordinateOfPiece.getXCoordi();
		int y = coordinateOfPiece.getYCoordi();
		
		piece.addCoordi(x, y);
		getLine(y).setPieceInLine(x,piece);
	}
	
	public String printBoard() {
		StringBuilder board = new StringBuilder();
		for (Line line : lines)
			board = board.append(appendNewLine(line.printLineByRepresentation()));	
		return board.toString();
	}
	
	
	//counter
	public int getCount(Piece.Type type, Piece.Color color) {
		int count = 0;
		for (Line line : lines)
			count += line.getCountInLine(type, color);
		return count;
	}
	
	private int getCountOfVerticalPawns(Piece.Color color) {
		int total = 0;
		if (getCount(Piece.Type.PAWN, color) < 2)
			return 1;
		
		for (int index=0; index<Board.BOARD_LINES; index++) {
			int count = 0;
			for (Line line : lines) {
				if (line.getPieceInLine(index).getType() == Piece.Type.PAWN && line.getPieceInLine(index).getColor() == color)
					count ++;
			}
			if (count > 1)
				total += count;
		}
		return total;
	}

	
	//scorer
	public double getScore(Piece.Color color) {
		return (getScoreOfQueen (color) + getScoreOfRook (color) + getScoreOfBishop (color) + getScoreOfKnight (color) + getScoreOfPawn (color));
	}
	private double getScoreOfPiece (Piece.Type type, Piece.Color color) {
		return (getCount(type, color) * type.getPoints()); 
	}
	public double getScoreOfQueen(Piece.Color color) {
		return getScoreOfPiece(Piece.Type.QUEEN, color);
	}
	public double getScoreOfRook(Piece.Color color) {
		return getScoreOfPiece(Piece.Type.ROOK, color);
	}
	public double getScoreOfBishop(Piece.Color color) {
		return getScoreOfPiece(Piece.Type.BISHOP, color);
	}
	public double getScoreOfKnight(Piece.Color color) {
		return getScoreOfPiece(Piece.Type.KNIGHT, color);
	}
	public double getScoreOfPawn(Piece.Color color) {
		return (getScoreOfPiece(Piece.Type.PAWN, color) - adjustVerticalPawn(color));
	}
	private double adjustVerticalPawn(Piece.Color color) {
		return (Board.POINTS_VERTICAL_PAWN * getCountOfVerticalPawns(color));
	}
	
	// pieceList
	public ArrayList<Piece> getSortedList(Piece.Color color) {
		ArrayList<Piece> sortedPieceList = getPieceList(color);
		Collections.sort(sortedPieceList);
		return sortedPieceList;
	}
	private ArrayList<Piece> getPieceList(Piece.Color color) {
		ArrayList<Piece> pieceList = new ArrayList<Piece>();
		for (Line line : lines)
			pieceList.addAll(line.getPieceListInLine(color));
		return pieceList;
	}
	
}
