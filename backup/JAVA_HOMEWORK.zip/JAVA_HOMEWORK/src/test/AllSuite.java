package test;

import junit.framework.TestSuite;

public class AllSuite extends TestSuite {
	
	public static TestSuite suite() {
		
		TestSuite suite = new TestSuite();
		
		suite.addTest(chess.AllTests.suite());
		suite.addTest(pieces.AllTests.suite());
		suite.addTest(util.AllTests.suite());
		
		return suite;
	}

}
