package pieces;

public class Coordinate {

	// instance variable
	private int xCoordi;
	private int yCoordi;
	private String code;
	private int code1stValue = 'a';
	private int code2ndValue = '1';
	
	// constructor
	private Coordinate (String code) {
		this.code = code;
		interpretCode();
	}
	private Coordinate (int x, int y) {
		this.xCoordi = x;
		this.yCoordi = y;
	}
	
	// factory method
	public static Coordinate create (String code) {
		return new Coordinate (code);
	}
	public static Coordinate create (int x, int y) {
		return new Coordinate (x, y);
	}
	
	// instance method
	private void interpretCode() {
		this.xCoordi = transfer1stCode(code.charAt(0));
		this.yCoordi = transfer2ndCode(code.charAt(1));
	}
	
	private int transfer1stCode (char codeValue) {
		return ((int)codeValue - code1stValue);
	}
	private int transfer1stCode () {
		return (xCoordi + code1stValue);
	}
	
	private int transfer2ndCode (char codeValue) {
		return ((int)codeValue - code2ndValue);
	}
	private int transfer2ndCode () {
		return (yCoordi + code2ndValue);
	}
	
	
	public int getXCoordi() {
		return this.xCoordi;
	}
	public int getYCoordi() {
		return this.yCoordi;
	}
	
	public String getCode () {
		StringBuilder sb = new StringBuilder();
		sb.append((char) transfer1stCode());
		sb.append((char) transfer2ndCode());
			
		return sb.toString();
	}

}
