package pieces;

import static util.StringUtil.NEWSPACE;

//import java.util.EnumMap;
//import java.util.Map;

public class Piece implements Comparable<Piece> {
	
	public enum Color {
		NONE(0), WHITE(1), BLACK(2);
		private int order;
		
		Color (int order) {
			this.order = order;
		}
	
		public int getOrderOfColor () {
			return this.order;
		}
	}
	
	public enum Type {
		NONE(0.0, NEWSPACE), PAWN(1.0, 'p'), KNIGHT(2.5, 'n'), BISHOP(3.0, 'b'), ROOK(5.0, 'r'), QUEEN(9.0, 'q'), KING(10.0, 'k');
		private double points;
		private char representation;
		
		Type (double points, char representation) {
			this.points = points;
			this.representation = representation;
		}
		
		public double getPoints () {
			return this.points;
		}
		
		public char getRepresentation() {
			return this.representation;
		}
	}
	
	private static Piece nonePiece = Piece.createNonePiece();
	private Piece.Type type;
	private Piece.Color color;
	private int x;
	private int y;
	
	// private constructor
	private Piece(Piece.Type type, Piece.Color color, char representation) {
		this.type = type;
		this.color = color;
	}
	
	// nonePiece singleton type
	public static Piece getNonePieceInstance() {
		return Piece.nonePiece;
	}
	
	
	@Override
	public int compareTo(Piece that) {
		double x = this.getType().getPoints();
		double y = that.getType().getPoints();
	
		if      (x>y)  return -1;
		else if (x==y) return 0;
		else		   return 1;
	}
	
	// instance method
	public boolean isWhite() {
		return this.color.equals(Piece.Color.WHITE);
	}	
	public boolean isBlack() {
		return this.color.equals(Piece.Color.BLACK);
	}
	
	public Piece.Color getColor() {
		return this.color;
	}
	public Piece.Type getType() {
		return this.type;
	}
	public char getRepresentation() {
		char type = this.getType().getRepresentation();
		if (this.getColor() == Piece.Color.WHITE)
			return type;
		else
			return Character.toUpperCase(type);
	}
	
	public double getPoints() {
		return this.getType().getPoints();
	}
	
	public void addCoordi(int x, int y) {
		this.x = x;
		this.y = y;
	}
	public String getCoordi () {
		return Coordinate.create(x, y).getCode();
	}

// Mapping Points to Type
//	private Map <Piece.Type, Double> points = null;
//	public static final double NONE_POINTS = 0.0;
//	public static final double PAWN_POINTS = 1.0;
//	public static final double KNIGHT_POINTS = 2.5;
//	public static final double ROOK_POINTS = 5.0;
//	public static final double BISHOP_POINTS = 3.0;
//	public static final double QUEEN_POINTS = 9.0;
//	public static final double KING_POINTS = 0.0;
//	
//	public double getPoints(Piece.Type type) {
//		return getPoint().get(type);
//	}
//	
//	private Map<Piece.Type, Double> getPoint() {
//		if (points == null)
//			loadPoints();
//		return points;
//	}
//	
//	private void loadPoints() {
//		points = new EnumMap<Piece.Type, Double>(Piece.Type.class);
//		
//		this.points.put(Piece.Type.NONE, Piece.NONE_POINTS);
//		this.points.put(Piece.Type.PAWN, Piece.PAWN_POINTS);
//		this.points.put(Piece.Type.KNIGHT, Piece.KNIGHT_POINTS);
//		this.points.put(Piece.Type.BISHOP, Piece.BISHOP_POINTS);
//		this.points.put(Piece.Type.ROOK, Piece.ROOK_POINTS);
//		this.points.put(Piece.Type.QUEEN, Piece.QUEEN_POINTS);
//		this.points.put(Piece.Type.KING, Piece.KING_POINTS);
//	}
//	

	// factory method	
	private static Piece createWhite (Piece.Type type) {
		return new Piece (type, Piece.Color.WHITE, type.getRepresentation());
	}
	private static Piece createBlack (Piece.Type type) {
		return new Piece (type, Piece.Color.BLACK, Character.toUpperCase(type.getRepresentation()));		
	}
	
	public static Piece createNonePiece () {
		Piece.Type type = Piece.Type.NONE;
		return new Piece (type, Piece.Color.NONE, type.getRepresentation());
	}
	
	public static Piece createWhitePawn () {
		return createWhite(Piece.Type.PAWN);
	}
	public static Piece createBlackPawn () {
		return createBlack(Piece.Type.PAWN);
	}
	public static Piece createWhiteKnight () {
		return createWhite(Piece.Type.KNIGHT);
	}
	public static Piece createBlackKnight () {
		return createBlack(Piece.Type.KNIGHT);
	}
	public static Piece createWhiteRook () {
		return createWhite(Piece.Type.ROOK);
	}
	public static Piece createBlackRook () {
		return createBlack(Piece.Type.ROOK);
	}
	public static Piece createWhiteBishop () {
		return createWhite(Piece.Type.BISHOP);
	}
	public static Piece createBlackBishop () {
		return createBlack(Piece.Type.BISHOP);
	}
	public static Piece createWhiteQueen () {
		return createWhite(Piece.Type.QUEEN);
	}
	public static Piece createBlackQueen () {
		return createBlack(Piece.Type.QUEEN);
	}
	public static Piece createWhiteKing () {
		return createWhite(Piece.Type.KING);
	}
	public static Piece createBlackKing () {
		return createBlack(Piece.Type.KING);
	}
	
}
