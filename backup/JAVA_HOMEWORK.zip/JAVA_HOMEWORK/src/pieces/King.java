package pieces;

public class King extends Piece{
	

}
