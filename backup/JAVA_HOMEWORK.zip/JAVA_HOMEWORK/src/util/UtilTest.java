package util;

import junit.framework.TestCase;

public class UtilTest extends TestCase {
	
	public void testStringUtil () {
		
		String testString = "qqqqqqqq";
		
		assertEquals (testString+'\n', StringUtil.appendNewLine(testString));
		assertEquals (testString+'\t', StringUtil.appendNewTap(testString));
		assertEquals (testString+' ', StringUtil.appendNewSpace(testString));
		
	}

}
