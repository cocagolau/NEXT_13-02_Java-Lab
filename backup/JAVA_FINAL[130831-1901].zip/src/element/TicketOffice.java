package element;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import simulation.Start;
import strategy.RoutingStrategy;

import map.TrainMap;


public class TicketOffice extends Department{

	private RoutingStrategy routingStrategy;
	private List<Staff> staffList = new ArrayList<Staff>();
	private List<Customer> movementList = new ArrayList<Customer>();
	private TrainMap tMap;
	
	
	// constructor	
	public TicketOffice(int strategyCode, int quota, TrainMap tMap) {
		super(quota);
		this.tMap = tMap;
		this.routingStrategy = RoutingStrategy.design(strategyCode, staffList);
	}

	
	// doneList
	public List<Customer> getMovementList() {
		return movementList;
	}

	// waitingLine
	@Override
	protected void putInLine(List<Customer> customers) {
		super.putInLine(customers);
	}

	// processing
	@Override
	protected void processingRegardOfTimePassed() {
		List<Customer> customers;
		movementList = new ArrayList<Customer>();
		
		for (Staff staff : staffList) {
//			staff.updateTime();
			staff.work();
			customers = staff.getDone();
			if (customers != null)
				movementList.addAll(customers);
		}
		
	}

	@Override
	protected void processingRegardlessOfTime() {
		employStaff(super.QUOTA);
		routingStrategy.sendToStaff(super.waitingLine);
	}
	
	private void employStaff(int number) {
		if (staffList.size() == 0) {
			for (int i=0; i<number; i++)
				staffList.add(new Staff(tMap));
		}
	}

}
