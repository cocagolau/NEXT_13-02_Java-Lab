package element;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import simulation.Start;
import utility.Parser;

import map.MapParser;
import map.Region;

import element.Customer;

import junit.framework.TestCase;

public class CustomerTest extends TestCase{

	File customerInfo;
	int id1;
	int id2;
	String name1;
	String name2;
	int arrivalTime;
	int processingTime;
	Region.Name departureStation;
	Region.Name arrivalStation;
		
	
	public void testCreateCustomer() {
		id1 = 1;
		id2 = 1;
		name1 = "customer1";
		name2 = "customer2";
		arrivalTime = 1;
		processingTime = 1;
		departureStation = Region.Name.Seoul;
		arrivalStation = Region.Name.Deajeon;
	
		Customer customer1 = Customer.create(id1, name1, arrivalTime, processingTime, departureStation, arrivalStation);
		Customer customer2 = Customer.create(id2, name2, arrivalTime, processingTime, departureStation, arrivalStation);
		
//		assertEquals (customer1, customer2);
		assertEquals (id1, customer1.getId());
		assertEquals (id2, customer2.getId());
//		assertEquals (name, customer.getName());
//		assertEquals (arrivalTime, customer.getArrivalTime());
//		assertEquals (ticketingTime, customer.getTicketingTime());
//		assertEquals (departureStation, customer.getDeparture());
//		assertEquals (arrivalStation, customer.getArrival());
//		assertEquals (travelTime, customer.getTravelTime());
		
	}
	

}
