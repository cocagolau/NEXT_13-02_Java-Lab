package element;

import java.util.ArrayList;
import java.util.List;

import utility.Dijkstra;
import map.TrainMap;


public class Staff {

	private Dijkstra dijkstra;
	private WaitingLine waitingLine = new WaitingLine();
	private boolean resting = false;
	private List<Customer> doneList = null;
	
	private Customer priority = null;
	private int processingTime = 0;
	
	public Staff(TrainMap tMap) {
		dijkstra = new Dijkstra(tMap);
	}

	public void put(Customer customer) {
		setWorking();
		waitingLine.enQueue(customer);
	}
	
	public void work() {  // �ϴ�.. 1�д��� ����
		if (priority == null) {
			if (!isResting()) {
				setWorking();
				priority = waitingLine.priority();
				priority.leaveWaitingLine();
				processingTime = 0;
			}
		}
		if (priority != null) {  // �켱�� ����
			// 1�д��� ����
			processingTime++;
			if (!priority.hasTravelTime())
				priority.setTravelTime(dijkstra.getShortestDistance(priority.getDepartureStation(), priority.getArrivalStation()));
			if (processingTime >= priority.getTimeRequiredForTicketing()) {
				priority.setWaitingTimeOfTicketing();
				priority.setDoneWithTicketing();
				doneList = waitingLine.deQueue(1);
				// priority init
				priority = null;
			}
		}
	}
	
	
	public List<Customer> getDone() {
		List<Customer> tempList;
		if (doneList == null)
			tempList = new ArrayList<Customer>();
		else
			tempList = doneList;
		doneList = null;
		
		return tempList;
	}
	
	
	public boolean isResting() {
		if (waitingLine.size() == 0) resting = true;
		return resting;
	}
	private void setWorking() {
		if (resting)
			resting = false;
	}
}
