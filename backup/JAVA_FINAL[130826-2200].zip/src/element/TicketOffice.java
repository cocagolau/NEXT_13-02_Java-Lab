package element;

import java.util.ArrayList;
import java.util.List;

import map.TrainMap;

import utility.Util;


public class TicketOffice extends Department{

	private int numberOfWorkingStaff = 0;
	private List<Staff> staffList = new ArrayList<Staff>();
	private List<Customer> movementList = null;
	private TrainMap tMap;
	
	
	// constructor	
	public TicketOffice(int quota, TrainMap tMap) {
		super(quota);
		this.tMap = tMap;
	}


	// waitingLine
	@Override
	public void putInLine(List<Customer> customers) {
		super.putInLine(customers);
		sortWaitingLine();
	}
	private void sortWaitingLine() {
		waitingLine.sortWaitingLine();
	}



	// processing
	@Override
	protected void processingRegardOfTimePassed() {
		movementList = new ArrayList<Customer>();
		numberOfWorkingStaff = 0;
		for (int i=0; i<staffList.size(); i++) {
			if (setStaff(staffList.get(i)).isWorking())
				numberOfWorkingStaff++;
			else
				movementList.add(staffList.remove(i--).getCustomer());
		}
	}

	@Override
	protected void processingRegardlessOfTime() {
		sendToStaff(getInLine(getNumberOfRestingStaff()));
	}
	
	
	// doneList
	public List<Customer> getMovementList() {
		if (movementList == null) return new ArrayList<Customer>();
		return movementList;
	}
	
	//staff
	public int getNumberOfWorkingStaff() {
		return numberOfWorkingStaff;
	}	
	public int getNumberOfRestingStaff() {
		return (QUOTA - getNumberOfWorkingStaff());  // �ð��� �޶����� ������ ��Ȯ�� ���� ��ȯ.
	}
	
	
	private void setWorkingStaff(int numberOfWorkingStaff) {
		this.numberOfWorkingStaff = numberOfWorkingStaff;
	}
	private Staff setStaff(Staff staff) {
		Customer customer = staff.getCustomer();
		if (!customer.hasTravelTime())
			staff.setTravelTime(tMap.getShortestDistance(customer.getDepartureStation(), customer.getArrivalStation()));			
		
		staff.setTime();
		return staff;
	}
	private void sendToStaff(List<Customer> customers) {
		for (Customer customer : customers) {
			customer.leaveLine();
			staffList.add(new Staff(customer, tMap));
		}
		setWorkingStaff(staffList.size());
	}

}
