package chess;

import java.util.List;

import board.Board;
import piece.Piece;

public class Game {
	
	// instance variable
	private Board board;

	
	// constructor
	public Game () {
		board = new Board();
		board.initialize();
	}
	
	
	// instance method
	////board
	public Board getBoard() {
		return this.board;
	}
	public String printBoard() {
		return board.printBoard();
	}
	public List<Piece> getSortedList(Piece.Color color) {
		return this.board.getSortedList(color);
	}

	
	//// piece
	public void put(String code, Piece piece) {
		board.putPiece(code, piece);
	}
	public Piece get(String code) {
		return this.board.getPiece(code);
	}
	public int getCount(Piece.Type type, Piece.Color color) {
		return this.board.getCount(type, color);
	}
	public void movePiece(String beforeCode, String afterCode) {
		Piece tempPiece = get(beforeCode);
		List<String> possibleMoves = tempPiece.getPossibleMoves();
		
		if (possibleMoves.contains(afterCode)) {
			put (beforeCode, get(afterCode));
			put (afterCode, tempPiece);
		}
	}
	
	
	////piece scorer
	public double getBlackScore() {
		return getScore(Piece.Color.BLACK);
	}
	public double getWhiteScore() {
		 return getScore(Piece.Color.WHITE);
	}
	private double getScore(Piece.Color color) {
		return  this.board.getScore(color);
	}


	// getPossibleMoves
	public List<String> getPossibleMoves(String code) {
		List<String> possibleMoves = get(code).getPossibleMoves();

		for (int i=0; i<possibleMoves.size(); i++) {		
			if (get(possibleMoves.get(i)).getType() != Piece.Type.NONE) {
				possibleMoves.remove(i);
				i--;
			}
		}
		return possibleMoves;
	}
}
