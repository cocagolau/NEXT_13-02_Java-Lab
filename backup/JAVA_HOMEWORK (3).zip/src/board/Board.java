package board;

import static util.Util.appendNewLine;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import piece.Piece;

public class Board {
	// class variable
	public static final int BOARD_LINES = 8;
	private static final double POINTS_VERTICAL_PAWN = 0.5;
	
	// instance variable
	private List<Line> lines = new ArrayList<Line>(8);
	
	
	// instance method
	//// initialize
	public void initialize () {		
		for (int i=0; i<Board.BOARD_LINES; i++)
			lines.add(Line.create());
	}
	
	
	//// board
	public Line getLine(int index) {
		return lines.get(index);
	}
	public String printBoard() {
		StringBuilder board = new StringBuilder();
		for (Line line : lines)
			board.append(appendNewLine(line.printLineByRepresentation()));
		return board.toString();
	}
	
	
	//// piece
	public void putPiece(String code, Piece piece) {
		piece.setPosition(code);
		getLine(piece.getY()).setPieceInLine(piece.getX(), piece);
	}
	public Piece getPiece(String code) {
		Position pos = new Position (code);
		return getLine(pos.getY()).getPieceInLine(pos.getX());
	}
	
	//// pieceList
	public List<Piece> getSortedList(Piece.Color color) {
		List<Piece> sortedPieceList = getPieceList(color);
		Collections.sort(sortedPieceList);
		return sortedPieceList;
	}
	private List<Piece> getPieceList(Piece.Color color) {
		List<Piece> pieceList = new ArrayList<Piece>();
		for (Line line : lines)
			pieceList.addAll(line.getPieceListInLine(color));
		return pieceList;
	}

	////piece counter
	public int getCount(Piece.Type type, Piece.Color color) {
		int count = 0;
		for (Line line : lines)
			count += line.getCountInLine(type, color);
		return count;
	}
	
	private int getCountOfVerticalPawns(Piece.Color color) {
		int total = 0;
		if (getCount(Piece.Type.PAWN, color) < 2)
			return 1;
		
		for (int index=0; index<Board.BOARD_LINES; index++) {
			int count = 0;
			for (Line line : lines) {
				if (line.getPieceInLine(index).getType() == Piece.Type.PAWN && line.getPieceInLine(index).getColor() == color)
					count ++;
			}
			if (count > 1)
				total += count;
		}
		return total;
	}
	
	//// piece score
	public double getScore(Piece.Color color) {
		return (  getScore (Piece.Type.QUEEN , color)
				+ getScore (Piece.Type.ROOK,   color)
				+ getScore (Piece.Type.BISHOP, color)
				+ getScore (Piece.Type.KNIGHT, color)
				+ getScore (Piece.Type.PAWN,   color));
	}
	
	private double getScore (Piece.Type type, Piece.Color color) {
		double score = getCount(type, color) * type.getPoints();
		
		if (type == Piece.Type.PAWN)
			return score - adjustVerticalPawn(color);
		
		return score; 
	}

	private double adjustVerticalPawn(Piece.Color color) {
		return (Board.POINTS_VERTICAL_PAWN * getCountOfVerticalPawns(color));
	}
}
