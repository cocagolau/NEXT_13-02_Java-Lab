package piece;


import java.util.List;


public class Pawn extends Piece{
	private Move[] moves = {Move.NW, Move.N, Move.NE};
	
	//constructor
	private Pawn (Piece.Color color) {
		super (Piece.Type.PAWN, color);
	}
	
	public static Pawn white() {
		return new Pawn (Piece.Color.WHITE);
	}
	
	public static Pawn black() {
		return new Pawn (Piece.Color.BLACK);
	}
	
	@Override
	public List<String> getPossibleMoves() {
		return getPossibleMoves(moves);
	}

	@Override
	protected void irregularMoves(int x, int y, Move move) {
		if (getColor() == Piece.Color.WHITE)
			pawnMoves(x+move.getX(), y-move.getY(), move, -move.getY());
		else
			pawnMoves(x+move.getX(), y+move.getY(), move, move.getY());
	}
	
	private void pawnMoves (int x, int y, Move move, int whenMoveIsUP) {
		putMovement (x, y);
		
		if (move == Piece.Move.N)
			putMovement (x, y + whenMoveIsUP);
		
	}
}
