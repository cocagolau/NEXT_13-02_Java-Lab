package piece;

import java.util.List;

public class NonePiece extends Piece {
	
	private static Piece nonePiece = NonePiece.createNonePiece();
	
	private NonePiece (Piece.Type type, Piece.Color color) {
		super (type, color);
	}
	
	public static NonePiece createNonePiece () {
		return new NonePiece (Piece.Type.NONE, Piece.Color.NONE);
	}
	
	// nonePiece singleton type
	public static Piece getInstance() {
		return NonePiece.nonePiece;
	}

	@Override
	public List<String> getPossibleMoves() {
		return null;
	}

}
