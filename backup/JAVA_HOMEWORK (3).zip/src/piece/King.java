package piece;

import java.util.List;

public class King extends Piece{
	private Move[] moves = {Move.NW, Move.N, Move.NE, Move.W, Move.E, Move.SW, Move.S, Move.SE};
	
	//constructor
	private King (Piece.Color color) {
		super (Piece.Type.KING, color);
	}
	
	public static King white() {
		return new King (Piece.Color.WHITE);
	}
	
	public static King black() {
		return new King (Piece.Color.BLACK);
	}

	@Override
	public List<String> getPossibleMoves() {
		return getPossibleMoves(moves);
	}
	
	@Override
	protected void irregularMoves(int x, int y, Move move) {	
		putMovement (x + move.getX(), y + move.getY());
	}
	
}