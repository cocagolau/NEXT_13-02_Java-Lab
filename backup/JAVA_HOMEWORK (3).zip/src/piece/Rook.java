package piece;

import java.util.List;

public class Rook extends Piece{
	private Move[] moves = {Move.W, Move.E, Move.N, Move.S};
	
	//constructor
	private Rook (Piece.Color color) {
		super (Piece.Type.ROOK, color);
	}
	
	public static Rook white() {
		return new Rook (Piece.Color.WHITE);
	}
	
	public static Rook black() {
		return new Rook (Piece.Color.BLACK);
	}
	
	@Override
	public List<String> getPossibleMoves() {
		return getPossibleMoves(moves);
	}
}
