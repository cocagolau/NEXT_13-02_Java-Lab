package test.piece;

import java.util.ArrayList;

import junit.framework.TestCase;
import piece.Piece;

public abstract class PieceTest extends TestCase {
	
	public abstract void testPiece();
	
	protected void verifyCreation (Piece whitePiece, Piece blackPiece, Piece.Type type, char representation, double points) {
		
		assertTrue(whitePiece.isWhite());
		assertEquals(type, whitePiece.getType());
		assertEquals(representation, whitePiece.getRepresentation());
		assertEquals (points, whitePiece.getPoints());
		
		assertTrue(blackPiece.isBlack());
		assertEquals(type, blackPiece.getType());
		assertEquals (Character.toUpperCase(representation), blackPiece.getRepresentation());
		assertEquals (points, blackPiece.getPoints());
	}
	
	protected String printPossibleMoves(ArrayList<String> possibleMoves) {
		if (possibleMoves == null)
			return "none";
		
		StringBuilder sb = new StringBuilder( );
		sb.append ("PossibleMoves :");
		
		for (String code : possibleMoves)
			sb.append (" " + code);
		
		return sb.toString();
	}
	
}
