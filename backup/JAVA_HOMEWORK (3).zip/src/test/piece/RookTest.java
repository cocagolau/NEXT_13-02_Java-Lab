package test.piece;

import piece.Piece;
import piece.Rook;

public class RookTest extends PieceTest {
	
	public void testPiece() {
		
		Piece.Type type = Piece.Type.ROOK;
		Piece whitePiece = Rook.white();
		Piece blackPiece = Rook.black();
		
		verifyCreation (whitePiece, blackPiece, type, type.getRepresentation(), type.getPoints());
		
//		whitePiece.addCoordi(4, 3);
////		System.out.println (printPossibleMoves(whitePiece.getPossibleMoves()));
//		assertEquals ("PossibleMoves : e1 a4 e2 b4 e3 c4 e4 d4 e5 e4 e6 f4 e7 g4 e8 h4", printPossibleMoves(whitePiece.getPossibleMoves()));
//		
//		blackPiece.addCoordi(3, 5);
////		System.out.println (printPossibleMoves(blackPiece.getPossibleMoves()));
//		assertEquals ("PossibleMoves : d1 a6 d2 b6 d3 c6 d4 d6 d5 e6 d6 f6 d7 g6 d8 h6", printPossibleMoves(blackPiece.getPossibleMoves()));
	}

}
