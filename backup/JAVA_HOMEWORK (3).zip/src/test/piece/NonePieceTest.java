package test.piece;

import static util.Util.NEWSPACE;
import piece.NonePiece;
import piece.Piece;

public class NonePieceTest extends PieceTest{
	
	public void testPiece () {
		Piece nonePiece = NonePiece.getInstance();
		
		assertEquals (NEWSPACE, nonePiece.getRepresentation());
		assertEquals (Piece.Type.NONE, nonePiece.getType());
	}

}
