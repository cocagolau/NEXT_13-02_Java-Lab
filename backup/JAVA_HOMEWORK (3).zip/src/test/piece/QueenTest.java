package test.piece;

import piece.Piece;
import piece.Queen;

public class QueenTest extends PieceTest {
	
	public void testPiece() {
		
		Piece.Type type = Piece.Type.QUEEN;
		Piece whitePiece = Queen.white();
		Piece blackPiece = Queen.black();
		
		verifyCreation (whitePiece, blackPiece, type, type.getRepresentation(), type.getPoints());
		
//		whitePiece.addCoordi(4, 3);
////		System.out.println (printPossibleMoves(whitePiece.getPossibleMoves()));
//		assertEquals ("PossibleMoves : e4 f5 g6 e4 d5 c6 b7 e4 d3 c2 e4 f3 g2 e1 a4 e2 b4 e3 c4 e4 d4 e5 e4 e6 f4 e7 g4 e8 h4", printPossibleMoves(whitePiece.getPossibleMoves()));
//		
//		blackPiece.addCoordi(3, 5);
////		System.out.println (printPossibleMoves(blackPiece.getPossibleMoves()));
//		assertEquals ("PossibleMoves : d6 e7 d6 c7 d6 c5 b4 d6 e5 f4 g3 d1 a6 d2 b6 d3 c6 d4 d6 d5 e6 d6 f6 d7 g6 d8 h6", printPossibleMoves(blackPiece.getPossibleMoves()));
	}

}
