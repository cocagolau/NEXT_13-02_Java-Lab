package test.piece;

import piece.Knight;
import piece.Piece;

public class KnightTest extends PieceTest {
	
	public void testPiece() {
		
		Piece.Type type = Piece.Type.KNIGHT;
		Piece whitePiece = Knight.white();
		Piece blackPiece = Knight.black();
		
		verifyCreation (whitePiece, blackPiece, type, type.getRepresentation(), type.getPoints());
		
//		whitePiece.addCoordi(4, 3);
////		System.out.println (printPossibleMoves(whitePiece.getPossibleMoves()));
//		assertEquals ("PossibleMoves : f6 f2 g5 g3 d6 d2 c5 c3", printPossibleMoves(whitePiece.getPossibleMoves()));
//		
//		blackPiece.addCoordi(3, 5);
////		System.out.println (printPossibleMoves(blackPiece.getPossibleMoves()));
//		assertEquals ("PossibleMoves : e8 e4 f7 f5 c8 c4 b7 b5", printPossibleMoves(blackPiece.getPossibleMoves()));
	}

}
