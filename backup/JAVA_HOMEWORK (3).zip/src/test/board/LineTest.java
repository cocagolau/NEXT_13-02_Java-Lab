package test.board;

import java.util.ArrayList;

import board.Board;
import board.Line;

import junit.framework.TestCase;
import piece.King;
import piece.Pawn;
import piece.Piece;
import piece.Queen;
import piece.Rook;

public class LineTest extends TestCase {

	Line lineOfwPawn;
	Line lineOfbPawn;
	Line line;
	ArrayList<Piece> lineOfPawns;
	String testP = "pppppppp";
	String testCapitalP = "PPPPPPPP";
	
	public void setUp () {
		line = Line.create();
		lineOfwPawn = Line.create();
		lineOfbPawn = Line.create();
	}
	
	public void testLine () {	
		for (int i = 0; i<Board.BOARD_LINES; i++) {
			lineOfwPawn.setPieceInLine(i, Pawn.white());
			lineOfbPawn.setPieceInLine(i, Pawn.black());
		}
		
		assertEquals (testCapitalP, lineOfbPawn.printLineByRepresentation());
		assertEquals (testP, lineOfwPawn.printLineByRepresentation());
	}
	
	public void testCount() {
		line.setPieceInLine (0, King.white());
		line.setPieceInLine (1, Pawn.black());
		line.setPieceInLine (2, King.black());
		line.setPieceInLine (3, Queen.black());
		line.setPieceInLine (4, Pawn.white());
		line.setPieceInLine (5, Rook.white());
		line.setPieceInLine (6, Pawn.black());
	
		assertEquals (2, line.getCountInLine(Piece.Type.PAWN, Piece.Color.BLACK));
		assertEquals ('k', line.getPieceInLine(0).getRepresentation());
	}

}
