package test.chess;

import static util.Util.appendNewLine;

import java.util.ArrayList;
import java.util.List;

import chess.Game;

import board.Board;

import piece.Bishop;
import piece.King;
import piece.Knight;
import piece.Pawn;
import piece.Piece;
import piece.Queen;
import piece.Rook;
import junit.framework.TestCase;

public class GameTest extends TestCase{
	
	Game game;
	Board board;
	
	List<String> b1, c1, a2, c2, d2, b3, e3;
	List<String> f5, g5, f6, h6, f7, g7, e8, f8;
	
	
	public void setUp () {		
		game = new Game();
		gameInit();
	}
	private void gameInit () {
		//black
		game.put("b1", King.black());
		game.put("c1", Rook.black());
		game.put("a2", Pawn.black());
		game.put("c2", Pawn.black());
		game.put("d2", Bishop.black());
		game.put("b3", Pawn.black());
		game.put("e3", Queen.black());
		//white
		game.put("f5", Knight.white());
		game.put("g5", Queen.white());
		game.put("f6", Pawn.white());
		game.put("h6", Pawn.white());
		game.put("f7", Pawn.white());
		game.put("g7", Pawn.white());
		game.put("e8", Rook.white());
		game.put("f8", King.white());
	}
	public void testCreateBoardInit() {
		String[] line = {".KR.....", "P.PB....", ".P..Q...", "........", ".....nq.", ".....p.p", ".....pp.", "....rk..",};
		
		StringBuilder sb = new StringBuilder();
		for (int i=0; i<Board.BOARD_LINES; i++)
			sb.append(appendNewLine(line[i]));
		assertEquals (sb.toString(), game.printBoard());
	}
	
	public void testCoordi() {
		assertEquals (Piece.Type.KING, game.get("b1").getType());
		assertEquals (Piece.Type.ROOK, game.get("c1").getType());
		assertEquals (Piece.Type.PAWN, game.get("a2").getType());
		assertEquals (Piece.Type.PAWN, game.get("c2").getType());
		assertEquals (Piece.Type.BISHOP, game.get("d2").getType());
		assertEquals (Piece.Type.PAWN, game.get("b3").getType());
		assertEquals (Piece.Type.QUEEN, game.get("e3").getType());
		
		assertEquals (Piece.Type.KNIGHT, game.get("f5").getType());
		assertEquals (Piece.Type.QUEEN, game.get("g5").getType());
		assertEquals (Piece.Type.PAWN, game.get("f6").getType());
		assertEquals (Piece.Type.PAWN, game.get("h6").getType());
		assertEquals (Piece.Type.PAWN, game.get("f7").getType());
		assertEquals (Piece.Type.PAWN, game.get("g7").getType());
		assertEquals (Piece.Type.ROOK, game.get("e8").getType());
		assertEquals (Piece.Type.KING, game.get("f8").getType());
	}
	
	
	
	public void testCount () {
		assertEquals (3, game.getCount(Piece.Type.PAWN, Piece.Color.BLACK));
		assertEquals (4, game.getCount(Piece.Type.PAWN, Piece.Color.WHITE));
	}
	
	
	public void testScore () {
		assertEquals (20.0, game.getBlackScore());
		assertEquals (19.5, game.getWhiteScore());
	}
	
	public void testSort () {
		List<Piece> whitePieceList, blackPieceList;
		whitePieceList = game.getSortedList(Piece.Color.WHITE);
		blackPieceList = game.getSortedList(Piece.Color.BLACK);
		
		// black
		assertEquals ('K', blackPieceList.get(0).getRepresentation());
		assertEquals ('Q', blackPieceList.get(1).getRepresentation());
		assertEquals ('R', blackPieceList.get(2).getRepresentation());
		assertEquals ('B', blackPieceList.get(3).getRepresentation());
		assertEquals ('P', blackPieceList.get(4).getRepresentation());
		assertEquals ('P', blackPieceList.get(5).getRepresentation());
		assertEquals ('P', blackPieceList.get(6).getRepresentation());
		
		// white
		assertEquals ('k', whitePieceList.get(0).getRepresentation());
		assertEquals ('q', whitePieceList.get(1).getRepresentation());
		assertEquals ('r', whitePieceList.get(2).getRepresentation());
		assertEquals ('n', whitePieceList.get(3).getRepresentation());
		assertEquals ('p', whitePieceList.get(4).getRepresentation());
		assertEquals ('p', whitePieceList.get(5).getRepresentation());
		assertEquals ('p', whitePieceList.get(6).getRepresentation());
		assertEquals ('p', whitePieceList.get(7).getRepresentation());	
	}

	
	public void testMovesOfPiece() {
		initMoves();
		
		// black
		assertEquals (b1, game.get("b1").getPossibleMoves());
		assertEquals (c1, game.get("c1").getPossibleMoves());
		assertEquals (a2, game.get("a2").getPossibleMoves());
		assertEquals (c2, game.get("c2").getPossibleMoves());
		assertEquals (d2, game.get("d2").getPossibleMoves());
		assertEquals (b3, game.get("b3").getPossibleMoves());
		assertEquals (e3, game.get("e3").getPossibleMoves());
		
		// white
		assertEquals (f5, game.get("f5").getPossibleMoves());
		assertEquals (g5, game.get("g5").getPossibleMoves());
		assertEquals (f6, game.get("f6").getPossibleMoves());
		assertEquals (h6, game.get("h6").getPossibleMoves());
		assertEquals (f7, game.get("f7").getPossibleMoves());
		assertEquals (g7, game.get("g7").getPossibleMoves());
		assertEquals (e8, game.get("e8").getPossibleMoves());
		assertEquals (f8, game.get("f8").getPossibleMoves());	
	}
	
	private void initMoves() {
		// black
		b1 = new ArrayList<String>();
		addMachine (b1, "a2, b2, c2, a1, c1");
		
		c1 = new ArrayList<String>();
		addMachine (c1, "b1, a1, d1, e1, f1, g1, h1, c2, c3, c4, c5, c6, c7, c8");
		
		a2 = new ArrayList<String>();
		addMachine (a2, "a3, a4, b3");
		
		c2 = new ArrayList<String>();
		addMachine (c2, "b3, c3, c4, d3");
		
		d2 = new ArrayList<String>();
		addMachine (d2, "c3, b4, a5, e3, f4, g5, h6, c1, e1");
		
		b3 = new ArrayList<String>();
		addMachine (b3, "a4, b4, b5, c4");
		
		e3 = new ArrayList<String>();
		addMachine (e3, "d4, c5, b6, a7, e4, e5, e6, e7, e8, f4, g5, h6, d3, c3, b3, a3, f3, g3, h3, d2, c1, e2, e1, f2, g1");
		
		// white
		f5 = new ArrayList<String>();
		addMachine (f5, "d6, e7, d4, e3, h6, g7, h4, g3");
		
		g5 = new ArrayList<String>();
		addMachine (g5, "f6, e7, d8, g6, g7, g8, h6, f5, e5, d5, c5, b5, a5, h5, f4, e3, d2, c1, g4, g3, g2, g1, h4");
		
		f6 = new ArrayList<String>();
		addMachine (f6, "e5, f5, f4, g5");
		
		h6 = new ArrayList<String>();
		addMachine (h6, "g5, h5, h4");
		
		f7 = new ArrayList<String>();
		addMachine (f7, "e6, f6, f5, g6");
		
		g7 = new ArrayList<String>();
		addMachine (g7, "f6, g6, g5, h6");
		
		e8 = new ArrayList<String>();
		addMachine (e8, "d8, c8, b8, a8, f8, g8, h8, e7, e6, e5, e4, e3, e2, e1");
		
		f8 = new ArrayList<String>();
		addMachine (f8, "e8, g8, e7, f7, g7");
	}
		
	
	public void testPossibleMoves() {
		initPossibleMoves();
		
		// black
		assertEquals (b1, game.getPossibleMoves("b1"));
		assertEquals (c1, game.getPossibleMoves("c1"));
		assertEquals (a2, game.getPossibleMoves("a2"));
		assertEquals (c2, game.getPossibleMoves("c2"));
		assertEquals (d2, game.getPossibleMoves("d2"));
		assertEquals (b3, game.getPossibleMoves("b3"));
		assertEquals (e3, game.getPossibleMoves("e3"));
		
		// white
		assertEquals (f5, game.getPossibleMoves("f5"));
		assertEquals (g5, game.getPossibleMoves("g5"));
		assertEquals (f6, game.getPossibleMoves("f6"));
		assertEquals (h6, game.getPossibleMoves("h6"));
		assertEquals (f7, game.getPossibleMoves("f7"));
		assertEquals (g7, game.getPossibleMoves("g7"));
		assertEquals (e8, game.getPossibleMoves("e8"));
		assertEquals (f8, game.getPossibleMoves("f8"));	
	}

	private void initPossibleMoves() {
		// black
		b1 = new ArrayList<String>();
		addMachine (b1, "b2, a1");
		
		c1 = new ArrayList<String>();
		addMachine (c1, "a1, d1, e1, f1, g1, h1, c3, c4, c5, c6, c7, c8");
		
		a2 = new ArrayList<String>();
		addMachine (a2, "a3, a4");
		
		c2 = new ArrayList<String>();
		addMachine (c2, "c3, c4, d3");
		
		d2 = new ArrayList<String>();
		addMachine (d2, "c3, b4, a5, f4, e1");
		
		b3 = new ArrayList<String>();
		addMachine (b3, "a4, b4, b5, c4");
		
		e3 = new ArrayList<String>();
		addMachine (e3, "d4, c5, b6, a7, e4, e5, e6, e7, f4, d3, c3, a3, f3, g3, h3, e2, e1, f2, g1");
		
		// white
		f5 = new ArrayList<String>();
		addMachine (f5, "d6, e7, d4, h4, g3");
		
		g5 = new ArrayList<String>();
		addMachine (g5, "e7, d8, g6, g8, e5, d5, c5, b5, a5, h5, f4, g4, g3, g2, g1, h4");
		
		f6 = new ArrayList<String>();
		addMachine (f6, "e5, f4");
		
		h6 = new ArrayList<String>();
		addMachine (h6, "h5, h4");
		
		f7 = new ArrayList<String>();
		addMachine (f7, "e6, g6");
		
		g7 = new ArrayList<String>();
		addMachine (g7, "g6");
		
		e8 = new ArrayList<String>();
		addMachine (e8, "d8, c8, b8, a8, g8, h8, e7, e6, e5, e4, e2, e1");
		
		f8 = new ArrayList<String>();
		addMachine (f8, "g8, e7");
	}
	
	
	private void addMachine(List<String> list, String codes) {
		for (String code : codes.split(", "))
			list.add(code);
	}
	public void testMove() {
		Piece bK = game.get("b1");
		
		System.out.println (game.printBoard());
		System.out.println ("---------------");
		game.movePiece("b1", "b2");
		assertEquals (game.get("b2"), bK);
		System.out.println (game.printBoard());
	}


}
