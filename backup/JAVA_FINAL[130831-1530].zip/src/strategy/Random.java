package strategy;

import java.util.List;

import element.Customer;
import element.Staff;
import element.WaitingLine;

import simulation.Start;

public class Random extends RoutingStrategy {

	public Random(List<Staff> staffList) {
		super(staffList);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void sendToStaff(WaitingLine waitingLine) {
		List<Customer> customers = waitingLine.deQueueAll();
		int i=0;
		for (Customer customer : customers) {
			customer.leaveWaitingLine();
			restingStaffList.get(i%Start.NUMBER_OF_STAFF).put(customer);
			i++;
		}
	}

}
