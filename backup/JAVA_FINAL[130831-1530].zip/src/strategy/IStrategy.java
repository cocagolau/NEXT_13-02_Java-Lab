package strategy;

import java.util.List;

import element.WaitingLine;

public interface IStrategy {

//	public int getNumberOfRestingStaff();
//	public void setRestingStaffList();
	public void sendToStaff(WaitingLine waitingLine);

}
