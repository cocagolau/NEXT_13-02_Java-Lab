package strategy;

import java.util.List;

import element.Customer;
import element.Staff;
import element.WaitingLine;


public class LeastWaiting extends RoutingStrategy {
	
	public LeastWaiting (List<Staff> staffList) {
		super(staffList);
	}
	
	@Override
	public void sendToStaff(WaitingLine waitingLine) {
		setRestingStaffList();
		waitingLine.sortWaitingLine();
//		Staff staff;
		int i=0;
//		System.out.println("restingStaff: " + getNumberOfRestingStaff());
		for (Customer customer : waitingLine.deQueue(getNumberOfRestingStaff())) {
			customer.leaveWaitingLine();
			restingStaffList.get(i++).put(customer);
//			System.out.println(customer.getId() +": " + customer.getName());
//			staff = restingStaffList.get(i);
//			staff.put(customer);
//			staff.execute(customer);
//			i++;
		}
	}

}
