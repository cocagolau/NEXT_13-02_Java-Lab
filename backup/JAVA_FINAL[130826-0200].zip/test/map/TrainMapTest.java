package map;


import element.Customer;
import element.Staff;
import simulation.Start;
import utility.Parser;

import map.TrainMap;
import junit.framework.TestCase;

public class TrainMapTest extends TestCase{
	
	TrainMap tMap;
	MapParser mapParser;
	Region.Name name = Region.Name.Seoul;
	
	Staff staff;
	Customer customer;
	
	public void setUp() {
		mapParser = new MapParser(Start.TRAIN_MAP_PATH, Parser.Separator.TAP);
		tMap = TrainMap.create(mapParser.getToRegionList(), mapParser.getCreations());
		
		customer = Customer.create(1, "customer1", 1, 1, Region.Name.Seoul, Region.Name.Deajeon);
		staff = new Staff(customer, tMap);
	}
	
	public void testGetShortestDistance() {
		assertEquals (20, tMap.getShortestDistance(Region.Name.Seoul, Region.Name.Asan));
		assertEquals (16, tMap.getShortestDistance(Region.Name.Seoul, Region.Name.Chuncheon));
		assertEquals (29, tMap.getShortestDistance(Region.Name.Seoul, Region.Name.Deajeon));
		assertEquals (22, tMap.getShortestDistance(Region.Name.Seoul, Region.Name.Wonju));
	}
	
	public void testContatinsKey() {
		assertTrue (tMap.containsKey(tMap.getRegion(Region.Name.Seoul)));
		assertFalse (tMap.containsKey(tMap.getRegion(Region.Name.Wonju)));
	}
	
}
