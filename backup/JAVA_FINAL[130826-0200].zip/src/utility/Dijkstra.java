package utility;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import map.Edge;
import map.Region;
import map.TrainMap;
import map.Region.Name;


public class Dijkstra {

	
//	Region --> Region.Name
	private TrainMap tMap;
//	private Map<Region, HashMap<Region, Integer>> shortestDistance = null;
//	private HashMap<Region, Integer> subShortestDistance = null;
	
	private boolean flag = false;
	private List<Region> tempRegions;
	private List<Region> defectiveList = null;
	private List<Edge> edgeList;
		
	public Dijkstra(TrainMap tMap, Region.Name name) {
		this.tMap = tMap;
		execute(name);
	}

	// subSD return method
//	public HashMap<Region, Integer> getShortestDistance(Region.Name name) {
//		checkKey(name);
//		
//		return subShortestDistance;
//	}
	Region getRegion(Region.Name name) {
		return tMap.getRegion(name);
	}	
	private void putKey(Region region, HashMap<Region, Integer> subResult) {
		tMap.putKey(region, subResult);		
	}
	private boolean containsKey(Region region) { // null�� ����??
		return tMap.containsKey(region);
	}
	
	// ��������??
	private void execute(Region.Name name) {
		Region region = getRegion(name);
//		if (!shortestDistance.containsKey(region)) {
		if (!containsKey(region)) {
			setSourceRegion(region);  // ���� ���� ���� ����
			calculateShortestDistance(region); // �ִܰŸ� ���
			updateDistance(region);  // ����� �ֽ�ȭ 
//			trainMapInit();  // map init;
		}
//		else
//			subShortestDistance = tMap.getValue(region);
	}	
	
	private void setSourceRegion(Region region) {
		region.setDistance(0); // �Ÿ� 0���� ����
		region.setDecided();  // �ִܰŸ� Ȯ�� ����
	}

	private void updateDistance(Region region) {
		HashMap<Region, Integer> subResult = new HashMap<Region, Integer>();

		for (Region tempRegion : tMap.getRegionList())
			if (!region.equals(tempRegion))  // �������� ����
				subResult.put(tempRegion, tempRegion.getDistance());

		// hashmap�� region�� Ű�� �ϴ� hashmap
//		shortestDistance.put(region, subShortestDistance);
		putKey(region, subResult);
	}

//	public Map<Region, HashMap<Region, Integer>> getCalculatedRegions(Region.Name name) {
//		if (shortestDistance == null)
//			shortestDistance = new HashMap<Region, HashMap<Region, Integer>>();
//
//		searchCalculateionRegions(name);  // ���Ǿ����� �˻�
//		return shortestDistance;
//	}


	private void calculateShortestDistance(Region region) {		
		tempRegions = new ArrayList<Region>();
		edgeList = region.getEdgeList();
		setFlag(false);
		
		//���� �ִ� �������� �̵��ϸ鼭 �Ÿ����
		traverseRegions(region);
		selectRegion(region);
		
	}
	private void traverseRegions(Region region) {
		Region nextRegion;
		for (Edge edge : edgeList) {
//			System.out.print (edge.getDistance());
			if (!edge.isUsed()) {
				edge.setUsed();
				setFlag(true);
				nextRegion = getRegion(edge.getOppositeRegionName(region.getName()));
				tempRegions.add(nextRegion);
				setDistance(nextRegion, (region.getDistance()+edge.getDistance()));
			}
//			System.out.println();
		}
		
	}
	private void selectRegion(Region region) {
		if (flag) {  // ����
			Collections.sort(tempRegions);
			calculateShortestDistance(getShortestRegion());
		}
		else {  // ������
			handleDefectiveRegion(region);  // �����ִ� region ó��
			checkCalculation();	
		}
	}

	private void handleDefectiveRegion(Region region) {
		if (region.isChosen() && !region.isDecided())
			region.setDecided();		
	}	
	private void checkCalculation() {
		if (hasDefectiveResult()) {
			for (Region re : defectiveList)
				calculateShortestDistance(re);
		}
	}
	
	// defectiveList
	private boolean hasDefectiveResult() {
		if (createDefectiveList() > 0) return true;
		return false;
	}
	private int createDefectiveList() {
		defectiveList = new ArrayList<Region>();
		for (Region tempR : tMap.getRegionList())
			if (!tempR.isDecided())
				defectiveList.add(tempR);
		
		return defectiveList.size();
	}

	private void setFlag(boolean onOff) {
		flag = onOff;
	}

	// shortestRegion ���� �� ��ȯ
	private Region getShortestRegion() {
		Region region = tempRegions.remove(0);
		region.setDecided();
		return region;
	}

	private void setDistance(Region nextRegion, int tempDistance) {
		if (nextRegion.isChosen()) {
			if (nextRegion.getDistance() > tempDistance) {
				nextRegion.setDistance(tempDistance);
			}
		}
		else // �Ÿ��� ���� ���, ����ȣ, ����
			nextRegion.setDistance(tempDistance);
	}




	// test method
//	String print() {
//		return tMap.print();
//	}
	// region�ʱ�ȭ
	void trainMapInit() {
		tMap.init();
	}
		
}
	

