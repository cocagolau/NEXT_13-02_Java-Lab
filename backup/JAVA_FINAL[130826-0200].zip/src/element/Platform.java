package element;

import java.util.List;

import map.TrainMap;

import simulation.Start;

public class Platform {

	
	static final int ALLOCATED_TIME = 5;
	
	private Train train = null;
	private boolean hasTrain = false;
	
	private int finalUpdateTime = 0;
	private int volumeOfTraffic = 0;
	
	private WaitingLine waitingLine;
	private int volumeOfPassensger = 0;
	
	private int offset = 0;
	
	
	
	// constructor
	// ������
	public Platform () {
		// train �߰� �ʿ�
		waitingLine = new WaitingLine();
//		this.QUOTA = quota;
	}

	// waitingLine
	public void putInLine(List<Customer> customers) {
		for (Customer customer : customers)
			customer.setArrivedAtPlatform();  // method�� leavePlatform���� �ٲٱ�
		waitingLine.putCustomer(customers);
		volumeOfPassensger += customers.size();		
	}
	private List<Customer> getInLine (int offset) {
		return waitingLine.getCustomer(waitingLine.getList().size()-offset);
	}
	
	public int getVolumeOfPassenger() {
		return volumeOfPassensger;
	}
	
	// platform
	public void process () {
		if (isPassTime()) {
			checkDone();
			updateTime();
		}
		if (hasTrain()) {
			sendToTrain(getInLine(offset));  // �������� ��� ����� ��������
		}
		offset = 0;
	}
	public void process(List<Customer> customers) {
		offset = customers.size();
		putInLine(customers);
		process();
	}
	
	private void checkDone() {
		if (isAllocatedTime())			
			setTrain();
		else
			train = null;
	}
	private void sendToTrain(List<Customer> customers) {
		train.put(customers);
		train.departFor();
	}


	// test
	boolean hasTrain() {
		if (train == null) hasTrain = false;
		return hasTrain;		
	}
	
	private void setTrain() {
		train = new Train();
		hasTrain = true;
	}
	private boolean isAllocatedTime() {
		return ( (Start.PRESENT_TIME % Platform.ALLOCATED_TIME) == 0 );
	}
	

	// time
	private boolean isPassTime() {
		return (Start.PRESENT_TIME > getFinalUpdateTime());
	}
	private int getFinalUpdateTime() {
		return finalUpdateTime;
	}
	private void updateTime() {
		finalUpdateTime = Start.PRESENT_TIME;
	}
	
	// train
	public int getVolumeOfTraffic() {
		if (hasTrain())	volumeOfTraffic += train.getVolumeOfTraffic();
		return volumeOfTraffic;
	}	

	
	// test method
	List<Customer> getWaitingLine() {
		return waitingLine.getList();
	}


}
