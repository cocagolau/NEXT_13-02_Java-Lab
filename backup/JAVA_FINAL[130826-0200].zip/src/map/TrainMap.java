package map;

import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

import utility.Util;

import map.Region.Name;

public class TrainMap{

	// ���� �����ڿ� �������� ������ �ҷ��ͼ� ������ �Ľ� �ʿ�.
//	private Region.Name[] regionList;
	private Map<Region, HashMap<Region, Integer>> shortestDistance;
	private List<Region.Name> regionList;
	private List<Region> regions;
	private List<Edge> edges;
	private Map<Region.Name, Region> regionCode = null;
	
	
	// private constructor
	private TrainMap (List<Region.Name> regionList, List<Edge> edges) {
		this.shortestDistance = new HashMap<Region, HashMap<Region, Integer>>();
		this.regionList = regionList;
		this.edges = edges;
		createRegion();
		connectRegions();
	}
	
	// factory
	public static TrainMap create(List<Region.Name> regionList, List<Edge> edges) {
		return new TrainMap(regionList, edges);
	}
	// hash
	public boolean containsKey(Region region) {
		return shortestDistance.containsKey(region);
	}
	public void putKey(Region region, HashMap<Region, Integer> subResult) {
		shortestDistance.put(region, subResult);
	}
	public HashMap<Region, Integer> getValue(Region region) {
		return shortestDistance.get(region);
	}
	
	//getter
	public int getShortestDistance(Region.Name from, Region.Name to) {
		Region fromRegion = getRegion(from);
		Region toRegion = getRegion(to);
		if(!containsKey(fromRegion)) return -1;

		return getValue(fromRegion).get(toRegion);
	}
	
	public Region getRegion(Region.Name name) {
		return regionCode.get(name);
	}
	public void init() {
		for (Region region : regions)
			region.init();
		for (Edge edge : edges)
			edge.init();
	}
	public List<Region> getRegionList() {
		return regions;
	}
	
	
	
	
	private void createRegion() {
		if (regionCode == null)  // hashmap ���� ��� ����
			regionCode = new HashMap<Region.Name, Region>();
		
		regions = new ArrayList<Region>();
		
		Region region;
		for (Region.Name name : regionList) {
			region = Region.create(name);
			regionCode.put(name, region);
			regions.add(region);
		}
	}
	
	// edges�� ��ȯ�Ͽ� ������ region�� edge�� ���۷����� �����ϴ� �ڵ�
	// edge�� �ִ� �ΰ��� region.name�� hash�� ������ region��ü�� �޾ƿ� ��, ������ ��ü�� edge�� ��ü�� ����
	private void connectRegions() {
		List<Region.Name> regionNameList;
		for (Edge edge : edges) {
			regionNameList = Arrays.asList(edge.getRegions());
			
			Region region;
			for (Region.Name name : regionNameList) {
				region = getRegion(name);
				region.addEdge(edge);
			}
		}
	}

	
	
	// ... test method
	List<Edge> getEdgeList() {
		return edges;
	}
	String print() {
		StringBuilder sb = new StringBuilder();
		for (Region region : regions)
			sb.append("Name: " + region.getName() + "[" + region.getDistance() + "],  ");
		return sb.toString();
	}
	Map<Region, HashMap<Region, Integer>> getShortestDistanceList() {
		return shortestDistance;
	}


}
