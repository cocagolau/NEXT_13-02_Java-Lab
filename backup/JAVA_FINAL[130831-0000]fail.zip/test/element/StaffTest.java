package element;

import simulation.Start;
import utility.Parser;
import map.MapParser;
import map.Region;
import map.TrainMap;
import element.Customer;
import junit.framework.TestCase;

public class StaffTest extends TestCase{
	
	Staff staff;
	Customer customer1, customer2;
	
	TrainMap tMap;
	MapParser mapParser;
	
	
	public void setUp() {
		mapParser = new MapParser(Start.TRAIN_MAP_PATH, Parser.Separator.TAP);
		tMap = TrainMap.create(mapParser.getToRegionList(), mapParser.getCreations());
		
		customer1 = Customer.create(1, "customer1", 1, 1, Region.Name.Seoul, Region.Name.Deajeon);
		customer2 = Customer.create(2, "customer2", 1, 2, Region.Name.Seoul, Region.Name.Deajeon);
		staff = new Staff(tMap);
	}
	
	public void testStaff() {
		assertEquals (null, staff.getDone());
		assertTrue (staff.isResting());
		
		staff.put(customer1);
		staff.put(customer2);
		assertFalse (staff.isResting());
		assertFalse (customer1.leftWaitingLine());
		assertFalse (customer2.leftWaitingLine());
		
		staff.plusOneMin();
		assertFalse (staff.isResting());
		assertEquals (customer1, staff.getDone().get(0));
		assertTrue (customer1.leftWaitingLine());
		assertFalse (customer2.leftWaitingLine());
		
		
		staff.plusOneMin();
		assertTrue (staff.isResting());
		assertEquals (customer2, staff.getDone().get(0));
		assertTrue (customer1.leftWaitingLine());
		assertTrue (customer2.leftWaitingLine());
	}
}
