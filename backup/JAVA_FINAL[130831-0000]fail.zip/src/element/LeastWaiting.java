package element;

import java.util.List;


public class LeastWaiting extends RoutingStrategy {
	
	public LeastWaiting (List<Staff> staffList) {
		super(staffList);
	}
	
	@Override
	public void sendToStaff(WaitingLine waitingLine) {
		setRestingStaffList();
		waitingLine.sortWaitingLine();
//		Staff staff;
		int i=0;
		for (Customer customer : waitingLine.deQueue(getNumberOfRestingStaff())) {
			customer.leaveWaitingLine();
			restingStaffList.get(i++).put(customer);
//			staff = restingStaffList.get(i);
//			staff.put(customer);
//			staff.execute(customer);
//			i++;
		}
	}

}
