package element;

import java.util.List;

import simulation.Start;


public class RoundRobbin extends RoutingStrategy {

	public RoundRobbin(List<Staff> staffList) {
		super(staffList);
	}

	@Override
	public void sendToStaff(WaitingLine waitingLine) {
		setRestingStaffList();
		List<Customer> customers = waitingLine.deQueueAll();
//		int restingStaff = getNumberOfRestingStaff();
//		System.out.println (restingStaff);
		int i=0;
		for (Customer customer : customers) {
//			customer.leaveWaitingLine();
			staffList.get(i%Start.NUMBER_OF_STAFF).put(customer);
			i++;
		}
	}

}
