package element;

import java.util.List;

import utility.Dijkstra;
import map.TrainMap;


public class Staff {

	private Dijkstra dijkstra;
	private WaitingLine waitingLine = new WaitingLine();
	private boolean resting = false;
	private List<Customer> doneList = null;
	
	
	public Staff(TrainMap tMap) {
		dijkstra = new Dijkstra(tMap);
	}

	public void put(Customer customer) {
		setWorking();
		waitingLine.enQueue(customer);
	}
	
	public List<Customer> getDone() {
		setDoneList();
		return doneList;
	}
	
	
//	public void plusOneMin() {
		// done list ����
//		Iterator<Customer> ir = waitingLine.iterator();
//		Customer customer;
//		while (ir.hasNext()) {
//			customer = ir.next();
//			customer.updateExpectedFinishTimeOfTicketing(1);
//			System.out.printf ("Id: %d, reqiredT: %d, expectedT: %d, \n", customer.getId(), customer.getTimeRequiredForTicketing(), customer.getExpectedFinishTimeOfTicketing()); 
//			customer.doneWithTicketing();
//			System.out.printf ("Id: %d [leftLine: %b]", customer.getId(), customer.leftWaitingLine());
//			customer.setWaitingTimeOfTicketing();
//		}
//		setDoneList();
//	}
	
	public void setDoneList() {
		Customer priority = null;
		doneList = null;
		if (waitingLine.size() != 0) {
			priority = waitingLine.priority();
			if (!priority.doneWithTicketing()) {
				if (!priority.leftWaitingLine()) {
//					priority.leaveWaitingLine();
					priority.setTravelTime(dijkstra.getShortestDistance(priority.getDepartureStation(), priority.getArrivalStation()));
				}
			}
			else {
				doneList = waitingLine.deQueue(1);
			}
		}
				
//		if (waitingLine.size() == 0)
//			doneList = null;
//		else if (!(priority = waitingLine.priority()).doneWithTicketing())   // �̰� ������ �ФФ�
//			doneList = null;
//		if (waitingLine.size() == 0 || !(priority = waitingLine.priority()).doneWithTicketing()) {
//			execute (priority);
//			doneList = waitingLine.deQueue(1);
//		}
	}
//	public void execute (Customer customer) {
//		customer.leaveWaitingLine();
//		customer.setTravelTime(dijkstra.getShortestDistance(customer.getDepartureStation(), customer.getArrivalStation()));
//	}
	

	
//	
//	public List<Customer> getDone() {
//		if (waitingLine.size() == 0)
//			return null;
//		
//		Customer priority = waitingLine.priority();
//		if (!priority.doneWithTicketing())
//			return null;
//		
//		execute (priority);
//		return waitingLine.deQueue(1);
//	}
	
	
	public boolean isResting() {
		if (waitingLine.size() == 0) resting = true;
		return resting;
	}
	private void setWorking() {
		if (resting)
			resting = false;
	}
	

}