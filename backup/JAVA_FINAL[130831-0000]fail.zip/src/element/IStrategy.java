package element;

import java.util.List;

public interface IStrategy {

//	public int getNumberOfRestingStaff();
//	public void setRestingStaffList();
	public void sendToStaff(WaitingLine waitingLine);

}
