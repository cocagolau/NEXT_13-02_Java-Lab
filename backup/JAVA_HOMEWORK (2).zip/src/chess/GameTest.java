//package chess;
//
//import pieces.Piece;
//import junit.framework.TestCase;
//
//public class GameTest extends TestCase{
//	
//	public void testCreate() {		
//		Game game = new Game();
//		Piece bKing = Piece.createBlackKing();
//		
//		assertEquals (1, game.getX(bKing));
//		assertEquals (1, game.gety(bKing));
//		 
//	}
//
//}
