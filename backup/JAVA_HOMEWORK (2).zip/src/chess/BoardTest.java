package chess;

import static util.StringUtil.*;
import java.util.ArrayList;

import pieces.Piece;
import junit.framework.TestCase;

public class BoardTest extends TestCase {
	
	Board board;
	
	public void setUp () {
		board = new Board();
		board.initialize();
	}
	
	public void testCreate() {
		Piece p1 = Piece.createBlackKing();
		Piece p2 = Piece.createBlackRook();
		Piece p3 = Piece.createWhiteKing();
		
		board.setPiece(p1, "b3");
		board.setPiece(p2, "b4");
		board.setPiece(p3, "c5");
		
		System.out.println (board.printBoard());
		
		assertEquals ("b3", p1.getCoordi());
		assertEquals ("b4", p2.getCoordi());
		assertEquals ("c5", p3.getCoordi());
		
	}
	
	
	public void testBoard() {
		String testP = "pppppppp";
		String testCapitalP = "PPPPPPPP";
		String testBlank = "        ";
		
		for (int i=0; i<Board.BOARD_LINES; i++) {
			board.getLine(0).setPieceInLine(i,Piece.createWhitePawn());
			board.getLine(1).setPieceInLine(i,Piece.createWhitePawn());
			board.getLine(6).setPieceInLine(i,Piece.createBlackPawn());
			board.getLine(7).setPieceInLine(i,Piece.createBlackPawn());
		}
		
		String blankRank = appendNewLine (testBlank);
		assertEquals (appendNewLine(testP) +
					  appendNewLine(testP) +
					  blankRank + 
					  blankRank + 
					  blankRank + 
					  blankRank + 
					  appendNewLine(testCapitalP) +
					  appendNewLine(testCapitalP), board.printBoard());
		
	}
	
	
	public void testCount () {
		boardInit1();
//		System.out.println (board.printBoard());
		assertEquals (3, board.getCount(Piece.Type.PAWN, Piece.Color.BLACK));
	}
	
	
	public void testScore () {
		boardInit1();
		
		// black
		assertEquals (9.0, board.getScoreOfQueen (Piece.Color.BLACK));
		assertEquals (3.0, board.getScoreOfBishop (Piece.Color.BLACK));
		assertEquals (5.0, board.getScoreOfRook (Piece.Color.BLACK));
		assertEquals (0.0, board.getScoreOfKnight (Piece.Color.BLACK));
		assertEquals (3.0, board.getScoreOfPawn (Piece.Color.BLACK));
		assertEquals (20.0, board.getScore (Piece.Color.BLACK));
		
		// white
		assertEquals (9.0, board.getScoreOfQueen (Piece.Color.WHITE));
		assertEquals (0.0, board.getScoreOfBishop (Piece.Color.WHITE));
		assertEquals (5.0, board.getScoreOfRook (Piece.Color.WHITE));
		assertEquals (2.5, board.getScoreOfKnight (Piece.Color.WHITE));
		assertEquals (3.0, board.getScoreOfPawn (Piece.Color.WHITE));
		assertEquals (19.5, board.getScore (Piece.Color.WHITE));
		
	}
	
	public void testSort () {
		boardInit1();
		ArrayList<Piece> whitePieceList, blackPieceList;
		whitePieceList = board.getSortedList(Piece.Color.WHITE);
		blackPieceList = board.getSortedList(Piece.Color.BLACK);
		
		// black
		assertEquals ('K', blackPieceList.get(0).getRepresentation());
		assertEquals ('Q', blackPieceList.get(1).getRepresentation());
		assertEquals ('R', blackPieceList.get(2).getRepresentation());
		assertEquals ('B', blackPieceList.get(3).getRepresentation());
		assertEquals ('P', blackPieceList.get(4).getRepresentation());
		assertEquals ('P', blackPieceList.get(5).getRepresentation());
		assertEquals ('P', blackPieceList.get(6).getRepresentation());
		
		// white
		assertEquals ('k', whitePieceList.get(0).getRepresentation());
		assertEquals ('q', whitePieceList.get(1).getRepresentation());
		assertEquals ('r', whitePieceList.get(2).getRepresentation());
		assertEquals ('n', whitePieceList.get(3).getRepresentation());
		assertEquals ('p', whitePieceList.get(4).getRepresentation());
		assertEquals ('p', whitePieceList.get(5).getRepresentation());
		assertEquals ('p', whitePieceList.get(6).getRepresentation());
		assertEquals ('p', whitePieceList.get(7).getRepresentation());
		
		
	}
	
	
	public void boardInit1 () {
		//black
		board.getLine(0).setPieceInLine(1, Piece.createBlackKing());
		board.getLine(0).setPieceInLine(2, Piece.createBlackRook());
		board.getLine(1).setPieceInLine(0, Piece.createBlackPawn());
		board.getLine(1).setPieceInLine(2, Piece.createBlackPawn());
		board.getLine(1).setPieceInLine(3, Piece.createBlackBishop());
		board.getLine(2).setPieceInLine(1, Piece.createBlackPawn());
		board.getLine(2).setPieceInLine(4, Piece.createBlackQueen());
		//white
		board.getLine(4).setPieceInLine(5, Piece.createWhiteKnight());
		board.getLine(4).setPieceInLine(6, Piece.createWhiteQueen());
		board.getLine(5).setPieceInLine(5, Piece.createWhitePawn());
		board.getLine(5).setPieceInLine(7, Piece.createWhitePawn());
		board.getLine(6).setPieceInLine(5, Piece.createWhitePawn());
		board.getLine(6).setPieceInLine(6, Piece.createWhitePawn());
		board.getLine(7).setPieceInLine(4, Piece.createWhiteRook());
		board.getLine(7).setPieceInLine(5, Piece.createWhiteKing());
	}

	
}
















