//package chess;
//
//import pieces.Piece;
//
//public class Game {
//
//	public int getX(Piece piece) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public int gety(Piece piece) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//}
