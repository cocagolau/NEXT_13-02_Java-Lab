package chess;

import java.util.ArrayList;

import junit.framework.TestCase;
import pieces.Piece;

public class LineTest extends TestCase {

	Line lineOfwPawn;
	Line lineOfbPawn;
	Line line;
	ArrayList<Piece> lineOfPawns;
	String testP = "pppppppp";
	String testCapitalP = "PPPPPPPP";
	
	public void setUp () {
		line = Line.create();
		lineOfwPawn = Line.create();
		lineOfbPawn = Line.create();
	}
	
	public void testLine () {
		
		for (int i = 0; i<Board.BOARD_LINES; i++) {
			lineOfwPawn.setPieceInLine(i, Piece.createWhitePawn());
			lineOfbPawn.setPieceInLine(i, Piece.createBlackPawn());
		}
		
		assertEquals (testCapitalP, lineOfbPawn.printLineByRepresentation());
		assertEquals (testP, lineOfwPawn.printLineByRepresentation());
	}
	
	public void testCount() {
		line.setPieceInLine (0, Piece.createWhiteKing());
		line.setPieceInLine (1, Piece.createBlackPawn());
		line.setPieceInLine (2, Piece.createBlackKing());
		line.setPieceInLine (3, Piece.createBlackQueen());
		line.setPieceInLine (4, Piece.createWhitePawn());
		line.setPieceInLine (5, Piece.createWhiteRook());
		line.setPieceInLine (6, Piece.createBlackPawn());
	
		assertEquals (2, line.getCountInLine(Piece.Type.PAWN, Piece.Color.BLACK));
		assertEquals ('k', line.getPieceInLine(0).getRepresentation());
	}

}
