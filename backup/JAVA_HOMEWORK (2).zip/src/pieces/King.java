package pieces;

public class King extends Piece{
	
	private King (Piece.Color color) {
		super (Piece.Type.KING, color, Piece.Type.KING.getRepresentation());
	}
		
	public static King createWhite () {
		return new King (Piece.Color.WHITE);
	}
	public static King createBlack () {
		return new King (Piece.Color.BLACK);
	}

}
