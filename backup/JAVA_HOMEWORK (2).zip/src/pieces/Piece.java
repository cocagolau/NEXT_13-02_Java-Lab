package pieces;

import static util.StringUtil.NEWSPACE;

public class Piece implements Comparable<Piece> {
	
	public enum Color {
		NONE(0), WHITE(1), BLACK(2);
		private int order;
		
		Color (int order) {
			this.order = order;
		}
	
		public int getOrderOfColor () {
			return this.order;
		}
	}
	
	public enum Type {
		NONE(0.0, NEWSPACE), PAWN(1.0, 'p'), KNIGHT(2.5, 'n'), BISHOP(3.0, 'b'), ROOK(5.0, 'r'), QUEEN(9.0, 'q'), KING(10.0, 'k');
		private double points;
		private char representation;
		
		Type (double points, char representation) {
			this.points = points;
			this.representation = representation;
		}
		
		public double getPoints () {
			return this.points;
		}
		
		public char getRepresentation() {
			return this.representation;
		}
	}
	
	private Piece.Type type;
	private Piece.Color color;
	private int x;
	private int y;
	
	// nonePiece singleton type
	private static Piece nonePiece = Piece.createNonePiece();
	public static Piece getNonePieceInstance() {
		return Piece.nonePiece;
	}
	
	// private constructor
	protected Piece(Piece.Type type, Piece.Color color, char representation) {
		this.type = type;
		this.color = color;
	}
	
	// factory method
	public static Piece createNonePiece () {
		Piece.Type type = Piece.Type.NONE;
		return new Piece (type, Piece.Color.NONE, type.getRepresentation());
	}
	

	// instance method
	public boolean isWhite() {
		return this.color.equals(Piece.Color.WHITE);
	}	
	public boolean isBlack() {
		return this.color.equals(Piece.Color.BLACK);
	}
	
	public Piece.Color getColor() {
		return this.color;
	}
	public Piece.Type getType() {
		return this.type;
	}
	public char getRepresentation() {
		char type = this.getType().getRepresentation();
		if (this.getColor() == Piece.Color.WHITE)
			return type;
		else
			return Character.toUpperCase(type);
	}
	public double getPoints() {
		return this.getType().getPoints();
	}
	
	public void addCoordi(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public String getCoordi () {
		return Coordinate.create(x, y).getCode();
	}

	
	@Override
	public int compareTo(Piece that) {
		double x = this.getType().getPoints();
		double y = that.getType().getPoints();
	
		if      (x>y)  return -1;
		else if (x==y) return 0;
		else		   return 1;
	}	
	
}
