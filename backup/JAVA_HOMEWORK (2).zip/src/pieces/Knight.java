package pieces;

public class Knight extends Piece {
	private Knight (Piece.Color color) {
		super (Piece.Type.KNIGHT, color, Piece.Type.KNIGHT.getRepresentation());
	}
		
	public static Knight createWhite () {
		return new Knight (Piece.Color.WHITE);
	}
	public static Knight createBlack () {
		return new Knight (Piece.Color.BLACK);
	}

}
