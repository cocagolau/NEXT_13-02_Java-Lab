package pieces;

import static util.StringUtil.*;
import junit.framework.TestCase;
import pieces.Piece;

public class PieceTest extends TestCase {
	
	Piece nonePiece;
	Piece wPawn, bPawn;
	Piece wKnight, bKnight;
	Piece wRook, bRook;
	Piece wBishop, bBishop;
	Piece wQueen, bQueen;
	Piece wKing, bKing;
	
	public void setUp () {
		nonePiece = Piece.getNonePieceInstance();
		wPawn = Pawn.createWhite();
		bPawn = Pawn.createBlack();
		wKnight = Knight.createWhite();
		bKnight = Knight.createBlack();
		wRook = Rook.createWhite();
		bRook = Rook.createBlack();
		wBishop = Bishop.createWhite();
		bBishop = Bishop.createBlack();
		wQueen = Queen.createWhite();
		bQueen = Queen.createBlack();
		wKing = King.createWhite();
		bKing = King.createBlack();
	}
	
	public void testCreate () {
		verifyCreation (wPawn, bPawn, Piece.Type.PAWN, PAWN_REPRESENTATION);
		verifyCreation (wKnight, bKnight, Piece.Type.KNIGHT, KNIGHT_REPRESENTATION);
		verifyCreation (wRook, bRook, Piece.Type.ROOK, ROOK_REPRESENTATION);
		verifyCreation (wBishop, bBishop, Piece.Type.BISHOP, BISHOP_REPRESENTATION);
		verifyCreation (wQueen, bQueen, Piece.Type.QUEEN, QUEEN_REPRESENTATION);
		verifyCreation (wKing, bKing, Piece.Type.KING, KING_REPRESENTATION);
		assertEquals (NEWSPACE, nonePiece.getRepresentation());
		assertEquals (Piece.Type.NONE, nonePiece.getType());
		
		assertEquals (0, Piece.Color.NONE.getOrderOfColor());
		assertEquals (1, Piece.Color.WHITE.getOrderOfColor());
		assertEquals (2, Piece.Color.BLACK.getOrderOfColor());
		
		
		assertEquals (0.0, Piece.Type.NONE.getPoints());
		assertEquals (1.0, Piece.Type.PAWN.getPoints());
		assertEquals (2.5, Piece.Type.KNIGHT.getPoints());
		assertEquals (5.0, Piece.Type.ROOK.getPoints());
		assertEquals (3.0, Piece.Type.BISHOP.getPoints());
		assertEquals (9.0, Piece.Type.QUEEN.getPoints());
		assertEquals (10.0, Piece.Type.KING.getPoints());
		
		assertEquals (1.0, wPawn.getPoints());
		assertEquals (1.0, bPawn.getPoints());
		assertEquals (2.5, wKnight.getPoints());
		assertEquals (2.5, bKnight.getPoints());
		assertEquals (5.0, wRook.getPoints());
		assertEquals (5.0, bRook.getPoints());
		assertEquals (3.0, wBishop.getPoints());
		assertEquals (3.0, bBishop.getPoints());
		assertEquals (9.0, wQueen.getPoints());
		assertEquals (9.0, bQueen.getPoints());
		assertEquals (10.0, wKing.getPoints());
		assertEquals (10.0, bKing.getPoints());			
	}

	
	public void verifyCreation (Piece whitePiece, Piece blackPiece, Piece.Type type, char representation) {
		
		assertTrue(whitePiece.isWhite());
		assertEquals(type, whitePiece.getType());
		assertEquals(representation, whitePiece.getRepresentation());
		
		assertTrue(blackPiece.isBlack());
		assertEquals(type, blackPiece.getType());
		assertEquals (Character.toUpperCase(representation), blackPiece.getRepresentation());
	}
	
}
