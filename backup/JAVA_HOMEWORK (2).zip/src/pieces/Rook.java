package pieces;

public class Rook extends Piece{
	private Rook (Piece.Color color) {
		super (Piece.Type.ROOK, color, Piece.Type.ROOK.getRepresentation());
	}
		
	public static Rook createWhite () {
		return new Rook (Piece.Color.WHITE);
	}
	public static Rook createBlack () {
		return new Rook (Piece.Color.BLACK);
	}


}
