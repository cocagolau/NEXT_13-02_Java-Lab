package pieces;

public class Queen extends Piece{
	private Queen (Piece.Color color) {
		super (Piece.Type.QUEEN, color, Piece.Type.QUEEN.getRepresentation());
	}
		
	public static Queen createWhite () {
		return new Queen (Piece.Color.WHITE);
	}
	public static Queen createBlack () {
		return new Queen (Piece.Color.BLACK);
	}

}
