package pieces;

public class Bishop extends Piece{
	
	private Bishop (Piece.Color color) {
		super (Piece.Type.BISHOP, color, Piece.Type.BISHOP.getRepresentation());
	}
		
	public static Bishop createWhite () {
		return new Bishop (Piece.Color.WHITE);
	}
	public static Bishop createBlack () {
		return new Bishop (Piece.Color.BLACK);
	}

}
