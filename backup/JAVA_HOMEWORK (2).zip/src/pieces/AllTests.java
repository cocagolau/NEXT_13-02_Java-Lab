package pieces;

import junit.framework.TestSuite;

public class AllTests extends TestSuite {
	
	public static TestSuite suite () {
		TestSuite suite = new TestSuite();
		suite.addTestSuite (PieceTest.class);
		suite.addTestSuite(CoordinateTest.class);
		return suite;
	}

}
