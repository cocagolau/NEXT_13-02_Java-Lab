package pieces;

public class Pawn extends Piece{
	
	private Pawn (Piece.Color color) {
		super (Piece.Type.PAWN, color, Piece.Type.PAWN.getRepresentation());
	}
		
	public static Pawn createWhite () {
		return new Pawn (Piece.Color.WHITE);
	}
	public static Pawn createBlack () {
		return new Pawn (Piece.Color.BLACK);
	}


}
