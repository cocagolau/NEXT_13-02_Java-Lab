package pieces;

import junit.framework.TestCase;

public class CoordinateTest extends TestCase {
	
	public void testCoordi () {
		String code = "a7";
		int x = 0;
		int y = 6;
		
		assertEquals (0, Coordinate.create(code).getXCoordi());
		assertEquals (6, Coordinate.create(code).getYCoordi());
		
		assertEquals ("a7", Coordinate.create(x,y).getCode());
	}

}
