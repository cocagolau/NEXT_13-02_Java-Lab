package utility;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import element.Customer;


public class Parser {

	public static final String IDENTIFIER = "	";
	private String infoPath;
	private FileReader reader = null;
	private BufferedReader bufferedReader = null;
	private List<Customer> customers = null;
	
	
	//private constructor
	private Parser (String infoPath) {
		this.infoPath = infoPath;
		parseDoc();
	}
	
	//factory
	public static Parser analyze (String infoPath) {
		return new Parser (infoPath);
	}
	
	public List<Customer> getCustomerList () {
		return customers;
	}


	private void parseDoc() {	
		try {
			String line;
			customers = new ArrayList<Customer>();
			reader = new FileReader(infoPath);
			bufferedReader = new BufferedReader (reader);
	
			while ( (line = bufferedReader.readLine()) != null ) {
				String[] parser = line.split(Parser.IDENTIFIER);
				customers.add(createCustomer (parser));
			}
		}
		catch (IOException ioe) { ioe.printStackTrace(); }
		catch (Exception e) { e.printStackTrace(); }
		finally {
			closeReader();
		}
	}

	private Customer createCustomer(String[] parser) {
		return
			Customer.create(
				Integer.parseInt(parser[0]),
				String.valueOf(parser[1]),
				Integer.parseInt(parser[2]),
				Integer.parseInt(parser[3]), 
				Util.Region(String.valueOf(parser[4])),
				Util.Region(String.valueOf(parser[5])), 
				Integer.parseInt(parser[6])
			);
	}
	
	private void closeReader() {
		if ( bufferedReader != null ) {
			try { bufferedReader.close(); }
			catch (IOException ioe) { ioe.printStackTrace(); }
		}
		
		if ( reader != null ) {
			try { reader.close(); }
			catch (IOException ioe) { ioe.printStackTrace(); }
		}
	}

}
