package map;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Dijkstra {

	private TrainMap tMap;
	private Map<Region, HashMap<Region, Integer>> calculatedRegions = null;
	private HashMap<Region, Integer> shortestDistance = null;
	
	private boolean flag = false;
	private List<Region> tempRegions;
	private List<Region> defectiveList = null;
	private List<Edge> edgeList;
	
	
	public Dijkstra(TrainMap tMap) {
		this.tMap = tMap;
	}

	public Region getRegion(Region.Name name) {
		return tMap.getRegion(name);
	}
	

	public Map<Region, HashMap<Region, Integer>> getCalculatedRegions(Region.Name name) {
		if (calculatedRegions == null)
			calculatedRegions = new HashMap<Region, HashMap<Region, Integer>>();

		searchCalculateionRegions(name);  // ���Ǿ����� �˻�
		return calculatedRegions;
	}

	private void searchCalculateionRegions(Region.Name name) {
		Region region = getRegion(name);
		if (!calculatedRegions.containsKey(region)) {
			setSourceRegion(region);  // ���� ���� ���� ����
			calculateShortestDistance(region); // �ִܰŸ� ���
			updateCalculationResult(region);  // ����� �ֽ�ȭ 
//			trainMapInit();  // map init;
		}
	}
	
	private void setSourceRegion(Region region) {
		region.setDistance(0); // �Ÿ� 0���� ����
		region.setDecided();  // �ִܰŸ� Ȯ�� ����
	}

	private void updateCalculationResult(Region region) {
		shortestDistance = new HashMap<Region, Integer>();

		for (Region tempRegion : tMap.getRegionList())
			if (!region.equals(tempRegion))  // �������� ����
				shortestDistance.put(tempRegion, tempRegion.getDistance());

		// hashmap�� region�� Ű�� �ϴ� hashmap
		calculatedRegions.put(region, shortestDistance);
		shortestDistance = null;
	}
	
	private void calculateShortestDistance(Region region) {		
		tempRegions = new ArrayList<Region>();
		edgeList = region.getEdgeList();
		flag = false;
		
		//���� �ִ� �������� �̵��ϸ鼭 �Ÿ����
		traverseRegions(region);
		
		// ���̻� �� �� �ִ� edge�� ���� ���
		if (flag) {
			Collections.sort(tempRegions);
			calculateShortestDistance(getShortestRegion());
		}
		else {
			handleDefectiveRegion(region);  // �����ִ� region ó��
			checkDefectiveCalculation();	
		}
	}
	
	private void checkDefectiveCalculation() {
		if (hasDefectiveResult()) {
			for (Region re : getDefectiveList())
				calculateShortestDistance(re);
		}
	}
	
	// defectiveList
	private List<Region> getDefectiveList() {
		return defectiveList;
	}

	private boolean hasDefectiveResult() {
		if (createDefectiveList() > 0) return true;
		return false;
	}

	private int createDefectiveList() {
		defectiveList = new ArrayList<Region>();
		for (Region tempR : tMap.getRegionList())
			if (!tempR.isDecided())
				defectiveList.add(tempR);
		
		return defectiveList.size();
	}

	private void traverseRegions(Region region) {
		Region nextRegion;
		for (Edge edge : edgeList) {
			if (!edge.isUsed()) {
				edge.setUsed();
				setFlag();		
				nextRegion = getRegion(edge.getOppositeRegionName(region.getName()));
				tempRegions.add(nextRegion);
				setDistance(nextRegion, (region.getDistance()+edge.getDistance()));
			}
		}
		
	}

	private void handleDefectiveRegion(Region region) {
		if (region.isChosen() && !region.isDecided())
			region.setDecided();		
	}

	private void setFlag() {
		flag = true;
	}

	// shortestRegion ���� �� ��ȯ
	private Region getShortestRegion() {
		Region region = tempRegions.remove(0);
		region.setDecided();
		return region;
	}

	private void setDistance(Region nextRegion, int tempDistance) {
		if (nextRegion.isChosen()) {
			if (nextRegion.getDistance() > tempDistance) {
				nextRegion.setDistance(tempDistance);
			}
		}
		else // �Ÿ��� ���� ���, ����ȣ, ����
			nextRegion.setDistance(tempDistance);
	}




	// test method
	String print() {
		return tMap.print();
	}
	// region�ʱ�ȭ
	void trainMapInit() {
		tMap.init();
	}
		
}
	

