package simulation;

import java.io.File;

import element.Station;

public class Start {

	public static final String CUSTOMER_INFO_PATH = "final_data" + File.separator + "customerInfo.txt";
	public static final String REPORT_PATH = "final_data" + File.separator + "report.txt";
	public static final String TESTREPORT_PATH = "final_data" + File.separator + "testReport.txt";
	public static boolean flag = false;
	public static int PRESENT_TIME = 0;
	
	public static void main (String[] args) {
		Station station = Station.create(Start.CUSTOMER_INFO_PATH);
		
		while (!flag)
			station.executeSimulation();

		System.out.println("Station Simulation Complete");
	}
}