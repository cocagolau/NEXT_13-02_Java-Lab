package element;


public class Staff {

	private Customer customer;
	private int time = 0;
	
	public Staff(Customer customer) {
		this.customer = customer;
		
	}

	public void setTime() {
		this.time ++; 
	}
	public int getTime() {
		return time;
	}

	public boolean isWorking() {
		if (time < customer.getTimeRequiredForTicketing()) {
			return true;
		}
		return false;
	}

	public Customer getCustomer() {
		return customer;
	}

}
