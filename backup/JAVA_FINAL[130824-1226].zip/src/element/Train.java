package element;

import java.util.List;

public class Train {
	
	private int volumeOfTraffic = 0;
	
	public void pullOutOfStation (List<Customer> customers) {
		if (customers != null) {
			volumeOfTraffic += customers.size();
			setPullOutOfStation(customers);
		}
		
	}
	
	private void setPullOutOfStation(List<Customer> customers) {
		for (Customer customer : customers) {
			customer.setPullOutOfStation();
			customer.setWaitingTimeAtPlatform();
		}
	}

	public int getVolumeOfTraffic () {
		return volumeOfTraffic;
	}


}
