package element;

import java.util.ArrayList;
import java.util.List;

import simulation.Start;
import utility.Parser;

public class Station {
	
	private TicketOffice ticketOffice = new TicketOffice();
	private WaitingLine waitingLine = new WaitingLine();
	private Platform platform = new Platform();
	private Train train = new Train();
	private List<Customer> customerInfo;
	private int departureTimeOfTheLastCustomer;
	
	//private constructor
	private Station (String infoPath) {
		customerInfo = Parser.analyze(infoPath).getCustomerList();
		checkDepartureTimeOfTheLastCustomer();
	}
	
	//factory
	public static Station create(String infoPath) {
		return new Station (infoPath);
	}

	public void executeSimulation() {
		lineCustomersUp();
		moveCustomersToTicketOffice();
		
		afterOneMinute();//////// �ð� ��ȭ �ʿ� +1
		
		moveCustomersToPlatform();
		boardTrain();	
		makeReport ();
	}
	
	
	private void afterOneMinute() {
		Start.PRESENT_TIME ++;		
	}

	private void makeReport () {
		if (train.getVolumeOfTraffic() == customerInfo.size()) {
			StationMaster.analyze(customerInfo).report(Start.REPORT_PATH);
			terminateSimulation();
		}
	}
	
	private void terminateSimulation() {
		Start.flag = true;
	}

	// ������ ������ �¿�
	private void boardTrain () {
		if (platform.hasTrain())
			train.pullOutOfStation(platform.getBoardingList());
	}
	
	
	// ��ǥ�ҿ��� �Ϸ�� �ο��� �÷������� �̵���Ŵ
	private void moveCustomersToPlatform() {
		List<Customer> completedList = ticketOffice.getCompletedList();
		if (completedList != null)
			platform.putWaitingList(completedList);
	}


	// ���� �ð��� ����ִ� ������ �˻� ��, �� �ο���ŭ ����ٿ��� ������ ��ǥ�ҷ� �̵���Ŵ
	private void moveCustomersToTicketOffice() {
		ticketOffice.putCustomers(waitingLine.getCustomer(ticketOffice.getNumberOfRestingStaff()));
	}

	// ������������ ����ð��� ������ ������ waitingLine���� �̵���Ŵ
	private void lineCustomersUp() {
		waitingLine.putCustomer(getLatestCustomerInfo());
	}
	private List<Customer> getLatestCustomerInfo() {
		List<Customer> subList = new ArrayList<Customer>();
		for (Customer customer : customerInfo)
			if (customer.getArrivalTimeAtTicketOffice() == Start.PRESENT_TIME)
				subList.add(customer);
		return subList;		
	}
	
	private void checkDepartureTimeOfTheLastCustomer() {
		int tempTime = 0;
		for (Customer customer : customerInfo)
			tempTime = customer.getArrivalTimeAtTicketOffice();			
			if (departureTimeOfTheLastCustomer < tempTime)
				departureTimeOfTheLastCustomer = tempTime;
	}
	
	public int getDepartureTimeOfTheLastCustomer() {
		return departureTimeOfTheLastCustomer;
	}
	
	
	// ...Test.class
	List<Customer> getCustomersList () {
		return customerInfo;
	}List<Customer> getWaitingLineList () {
		return waitingLine.getList();
	}


}
