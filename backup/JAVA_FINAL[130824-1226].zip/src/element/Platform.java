package element;

import java.util.ArrayList;
import java.util.List;

import simulation.Start;

public class Platform {

	private List<Customer> waitingList = null;
	private List<Customer> boardingList = null;
	private boolean train = false;
	private int allocationTime = 0;
	private int finalUpdateTime = 0;

	public void putWaitingList(List<Customer> customers) {
		if (waitingList == null)
			waitingList = new ArrayList<Customer>();
		setArrivedAtPlatform(customers);
		waitingList.addAll(customers);
	}

	private void setArrivedAtPlatform(List<Customer> customers) {
		for (Customer customer : customers)
			customer.setArrivedAtPlatform();		
	}

	public List<Customer> getBoardingList() {
		if (boardingList == null) return null;
		
		List<Customer> temp = boardingList;
		boardingList = null;
		train = false;
		
		return temp;
	}
	
	
	public boolean hasTrain() {  // �д��� üũ
		if (Start.PRESENT_TIME > finalUpdateTime)
			checkTrain();
		return train;
	}
	
	private void setFinalUpdateTime() {
		finalUpdateTime = Start.PRESENT_TIME;	
	}

	private void setAllocationTime(int supplementaryTime) {
		allocationTime += supplementaryTime;
		if (allocationTime >= 5) {
			boardingList = waitingList;
			waitingList = null;
			train = true;
			allocationTime = 0;
		}
	}
	private void checkTrain () {
		setAllocationTime(Start.PRESENT_TIME - finalUpdateTime);
		setFinalUpdateTime();
	}


	
	// ...test.class
	int getTime() {
		return allocationTime;
	}
	int getAllocationTime() {
		return allocationTime;
	}

	

}
