package map;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import junit.framework.TestCase;

public class DijkstraTest extends TestCase{
	
	Region.Name[] regionList = {Region.Name.Seoul, Region.Name.Asan, Region.Name.Chuncheon, Region.Name.Deajeon, Region.Name.Wonju, Region.Name.Gwangju, Region.Name.Kyungju};
	List<Edge> edges;
	Dijkstra dijkstra;
	HashMap<Region,Integer> shortestDistance;
	Map<Region, HashMap<Region, Integer>> formulatedRegions;
	String sf = "%10s:[%b, %2d]";
	
	public void setUp() {
		createEdges();
		dijkstra = new Dijkstra (TrainMap.create(regionList, edges));
	}
	private void createEdges() {
		edges = new ArrayList<Edge>();
		
		edges.add(Edge.create(Region.Name.Seoul, Region.Name.Asan, 20));
		edges.add(Edge.create(Region.Name.Seoul, Region.Name.Deajeon, 29));
		edges.add(Edge.create(Region.Name.Seoul, Region.Name.Wonju, 22));
		edges.add(Edge.create(Region.Name.Seoul, Region.Name.Chuncheon, 16));
		
		
		edges.add(Edge.create(Region.Name.Chuncheon, Region.Name.Wonju, 28));
		edges.add(Edge.create(Region.Name.Chuncheon, Region.Name.Kyungju, 31));
		
		edges.add(Edge.create(Region.Name.Wonju, Region.Name.Kyungju, 32));
		edges.add(Edge.create(Region.Name.Wonju, Region.Name.Deajeon, 23));
		
		edges.add(Edge.create(Region.Name.Deajeon, Region.Name.Kyungju, 15));
		edges.add(Edge.create(Region.Name.Deajeon, Region.Name.Gwangju, 12));
		edges.add(Edge.create(Region.Name.Deajeon, Region.Name.Asan, 35));
		
		edges.add(Edge.create(Region.Name.Asan, Region.Name.Gwangju, 25));
		
		edges.add(Edge.create(Region.Name.Kyungju, Region.Name.Gwangju, 18));		
	}
	
	
	
	
	public void testGetShortestDistanceOfOthersFrom() {
		Region.Name needTo = Region.Name.Deajeon;
		formulatedRegions = dijkstra.getCalculatedRegions(needTo);
		shortestDistance = formulatedRegions.get(dijkstra.getRegion(needTo));
		System.out.println ();
		System.out.println ();
		for (Region.Name name : regionList)
			if (!needTo.equals(name))
				System.out.println (name + ": " + shortestDistance.get(dijkstra.getRegion(name)));
	
	}
	

	public void testGetShortestDistance() {
		
		for (Region.Name needTo : regionList) {
			Region tempR = dijkstra.getRegion(needTo);
			formulatedRegions = dijkstra.getCalculatedRegions(needTo);
			shortestDistance = formulatedRegions.get(tempR);
			System.out.print (tempR.getName() + "::  ");
			System.out.print (String.format(sf, tempR.getName(), tempR.isDecided(), tempR.getDistance()) + "::  ");
			
			for (Region.Name name : regionList) {
				if (!needTo.equals(name)) {
					Region tempRR = dijkstra.getRegion(name);
					System.out.print (String.format(sf, tempRR.getName(), tempRR.isDecided(), tempRR.getDistance()) + ", ");
					System.out.print (tempRR.getName() + "[" + shortestDistance.get(tempRR) +"]    ");
				}
			}
			System.out.println();
			dijkstra.trainMapInit();
			
		}
		
	}

}
