package element;


import java.util.ArrayList;
import java.util.List;

import map.Region;

import simulation.Start;

import junit.framework.TestCase;

public class TicketOfficeTest extends TestCase {

	TicketOffice ticketOffice;
	List<Customer> customers1;
	List<Customer> customers2;
	
	public void setUp () {
		ticketOffice = new TicketOffice ();
		customers1 = new ArrayList<Customer>();

		customers1.add(Customer.create(1, "customer1", 0, 1, Region.Name.Seoul, Region.Name.Deajeon, 2));
		customers1.add(Customer.create(2, "customer2", 0, 2, Region.Name.Seoul, Region.Name.Deajeon, 2));
		customers1.add(Customer.create(3, "customer2", 0, 3, Region.Name.Seoul, Region.Name.Deajeon, 2));
		
		customers2 = new ArrayList<Customer>();
		customers2.add(Customer.create(1, "customer1", 0, 1, Region.Name.Seoul, Region.Name.Deajeon, 2));
		customers2.add(Customer.create(2, "customer2", 0, 1, Region.Name.Seoul, Region.Name.Deajeon, 2));
		customers2.add(Customer.create(3, "customer2", 0, 3, Region.Name.Seoul, Region.Name.Deajeon, 2));
		
	}
	
	
	public void testCheckStaff1() {
		Start.PRESENT_TIME = 0;
		
		assertEquals (3, ticketOffice.getNumberOfRestingStaff());
		
		Start.PRESENT_TIME++;
		ticketOffice.putCustomers(customers1);
		for (Customer customer : customers1) {
			assertTrue (customer.leaveWaitingLine());
			assertEquals (Start.PRESENT_TIME, customer.getActualTimeOfTicketing());
		}
		
		assertEquals (1, ticketOffice.getNumberOfRestingStaff());
		assertEquals (1, ticketOffice.getCompletedList().size());
		
		Start.PRESENT_TIME++;
		assertEquals (2, ticketOffice.getNumberOfRestingStaff());
		assertEquals (1, ticketOffice.getCompletedList().size());
		
		Start.PRESENT_TIME++;
		assertEquals (3, ticketOffice.getNumberOfRestingStaff());
		assertEquals (1, ticketOffice.getCompletedList().size());
	}
	
	public void testCheckStaff2() {
		Start.PRESENT_TIME = 0;
		assertEquals (3, ticketOffice.getNumberOfRestingStaff());
		
		Start.PRESENT_TIME++;
		ticketOffice.putCustomers(customers2);
		for (Customer customer : customers2) {
			assertTrue (customer.leaveWaitingLine());
			assertEquals (Start.PRESENT_TIME, customer.getActualTimeOfTicketing());
		}
		
		assertEquals (2, ticketOffice.getNumberOfRestingStaff());
		assertEquals (2, ticketOffice.getCompletedList().size());
		
		Start.PRESENT_TIME++;
		assertEquals (2, ticketOffice.getNumberOfRestingStaff());
		assertEquals (0, ticketOffice.getCompletedList().size());
		
		Start.PRESENT_TIME++;
		assertEquals (3, ticketOffice.getNumberOfRestingStaff());
		assertEquals (1, ticketOffice.getCompletedList().size());
	}
	
}
