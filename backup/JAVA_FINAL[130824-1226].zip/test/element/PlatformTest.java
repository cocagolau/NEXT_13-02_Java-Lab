package element;

import java.util.ArrayList;
import java.util.List;

import map.Region;

import simulation.Start;

import junit.framework.TestCase;

public class PlatformTest extends TestCase{

	Platform platform;
	List<Customer> customers1, customers2;
//	List<Customer>
	
	public void setUp () {
		platform = new Platform();
		customers1 = new ArrayList<Customer>();

		customers1.add(Customer.create(1, "customer1", 0, 1, Region.Name.Seoul, Region.Name.Deajeon, 2));
		customers1.add(Customer.create(2, "customer2", 0, 2, Region.Name.Seoul, Region.Name.Deajeon, 2));
		customers1.add(Customer.create(3, "customer2", 0, 3, Region.Name.Seoul, Region.Name.Deajeon, 2));
		
		customers2 = new ArrayList<Customer>();
		customers2.add(Customer.create(1, "customer1", 1, 1, Region.Name.Seoul, Region.Name.Deajeon, 2));
		customers2.add(Customer.create(2, "customer2", 2, 1, Region.Name.Seoul, Region.Name.Deajeon, 2));

	}
	
	public void testPut () {
		Start.PRESENT_TIME = 0;
		assertEquals (0, platform.getAllocationTime());
		
		assertFalse (platform.hasTrain());
		platform.putWaitingList(customers1);
		for (Customer customer : customers1)
			assertTrue(customer.arrivedAtPlatform());
		
		assertEquals (0, platform.getAllocationTime());
		
		
		for (int i=0; i<4; i++) {
			Start.PRESENT_TIME++;
			assertFalse (platform.hasTrain());
			assertEquals (i+1, platform.getAllocationTime());
		}
		platform.putWaitingList(customers2);
		for (Customer customer : customers2)
			assertTrue(customer.arrivedAtPlatform());
		
		Start.PRESENT_TIME++;
		assertTrue (platform.hasTrain());
		assertEquals (0, platform.getAllocationTime());
		assertEquals (5, platform.getBoardingList().size());
		
		Start.PRESENT_TIME++;
		assertFalse (platform.hasTrain());
		assertEquals (1, platform.getAllocationTime());
		assertEquals (null, platform.getBoardingList());
		
		
	}

}
