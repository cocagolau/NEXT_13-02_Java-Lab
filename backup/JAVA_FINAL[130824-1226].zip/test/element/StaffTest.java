package element;

import map.Region;
import element.Customer;
import junit.framework.TestCase;

public class StaffTest extends TestCase{
	
	Staff staff1;
	Staff staff2;
//	int time = 0;
	Customer customer1;
	Customer customer2;
	
	
	public void setUp() {
		customer1 = Customer.create(1, "customer1", 1, 1, Region.Name.Seoul, Region.Name.Deajeon, 1);
		customer2 = Customer.create(2, "customer2", 1, 2, Region.Name.Seoul, Region.Name.Deajeon, 1);
		staff1 = new Staff(customer1);
		staff2 = new Staff(customer2);
	}
	
	public void testCompleteTicketing() {
		staff1.setTime();
		staff2.setTime();
		assertEquals (1, staff1.getTime());
		assertEquals (1, staff2.getTime());
		
		// completeTicketing, customer --> platform
		assertEquals (false, staff1.isWorking());
		assertEquals (customer1, staff1.getCustomer());
		
		assertEquals (true,  staff2.isWorking());
		
		
		staff2.setTime();
		assertEquals (false, staff2.isWorking());
		assertEquals (customer2, staff2.getCustomer());
		
	}
}
