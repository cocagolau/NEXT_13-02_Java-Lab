package element;

import java.util.ArrayList;
import java.util.List;

import map.TrainMap;

import simulation.Start;


public class TicketOffice {

	private final int QUOTA;
	private List<Staff> staffList;
	private int numberOfWorkingStaff = 0;
	private TrainMap tMap;
	
	private WaitingLine waitingLine;
	private List<Customer> doneList = null;
	private int finalUpdateTime = 0;
	
	
	// constructor	
	public TicketOffice(int quota, TrainMap tMap) {
		staffList = new ArrayList<Staff>(quota);
		waitingLine = new WaitingLine();
		this.tMap = tMap;
		this.QUOTA = quota;
	}


	// waitingLine
	public void putInLine(List<Customer> customers) {
		waitingLine.putCustomer(customers);
		waitingLine.sortLine();		
	}
	private List<Customer> getInLine (int number) {
		return waitingLine.getCustomer(number);
	}
	
	
	
	
	// ticketOffice process
	public void process () {
		if (isPassTime()) {
			checkDone();
			updateTime();
		}
		sendToStaff(getInLine(getNumberOfRestingStaff()));
	}
	public void process(List<Customer> customers) {
		putInLine(customers);
		process();
	}
	
	private void sendToStaff(List<Customer> customers) {
		for (Customer customer : customers) {
			customer.leaveLine();
			staffList.add(new Staff(customer, tMap));
		}
		setWorkingStaff(staffList.size());
	}
	
	
	
	
	
	//about staff
	private void setWorkingStaff(int numberOfWorkingStaff) {
		this.numberOfWorkingStaff = numberOfWorkingStaff;
	}
	private Staff setStaff(Staff staff) {
		staff.setTime();
		return staff;
	}
	public int getNumberOfWorkingStaff() {
		return numberOfWorkingStaff;
	}	
	// �ð��� �޶����� ������ ��Ȯ�� ���� ��ȯ.
	public int getNumberOfRestingStaff() {
		return (QUOTA - getNumberOfWorkingStaff());
	}
	
	
	
	
	
	// doneList
	private void checkDone() {
		doneList = new ArrayList<Customer>();
		numberOfWorkingStaff = 0;
		for (int i=0; i<staffList.size(); i++) {
			if (setStaff(staffList.get(i)).isWorking())
				numberOfWorkingStaff++;
			else
				doneList.add(staffList.remove(i--).getCustomer());
		}
	}	
	public List<Customer> getMovingList() {
		if (doneList == null) return new ArrayList<Customer>();
		return doneList;
	}

	
	
	
	
	// time
	private boolean isPassTime() {
		return (Start.PRESENT_TIME > getFinalUpdateTime());
	}
	private int getFinalUpdateTime() {
		return finalUpdateTime;
	}
	private void updateTime() {
		finalUpdateTime = Start.PRESENT_TIME;
	}

	
	

	// test method
	List<Customer> getWaitingLine() {
		return waitingLine.getList();
	}

}
