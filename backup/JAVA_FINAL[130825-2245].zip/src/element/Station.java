package element;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import map.Edge;
import map.MapParser;
import map.Region;
import map.TrainMap;

import simulation.Start;
import utility.Parser;
import utility.Util;

public class Station {
		
	private TicketOffice ticketOffice;
	private Platform platform;
	private TrainMap tMap;
	private MapParser mapParser;
	
	private List<Customer> customerInfo;
	private List<Customer> movingList;
		
	private boolean isToMoveToPlatform = false;
	private boolean finishedInfo = false;
	private int departedCustomer = 0;
	private int finalUpdateTime = 0;
	
	
	
	//private constructor
	private Station (String infoPath) {
		mapParser = new MapParser(Start.TRAIN_MAP_PATH, Parser.Separator.TAP);
		tMap = TrainMap.create(mapParser.getToRegionList(), mapParser.getCreations());
		ticketOffice = new TicketOffice(Start.NUMBER_OF_STAFF, tMap);
		platform = new Platform();
		
		setCustomerInfo(
			new Parser(infoPath, Parser.Separator.TAP) {
				@Override
				protected Object createObject(String[] split) {
					return
						Customer.create(
							Integer.parseInt(split[0]),
							String.valueOf(split[1]),
							Integer.parseInt(split[2]),
							Integer.parseInt(split[3]), 
							Util.Region(String.valueOf(split[4])),
							Util.Region(String.valueOf(split[5])), 
							Integer.parseInt(split[6])
						);
				}
				@Override
				protected List createList(String[] split) {
					return null;
				}					
			}
		); 
	}
	
	private void setCustomerInfo(Parser parser) {
		customerInfo = parser.getCreations();
	}

	//factory
	public static Station create(String infoPath) {
		return new Station (infoPath);
	}

	public void executeSimulation() {
		processInOffice();
		processAtPlatform();
		makeReport();
	}
	

	private void processInOffice() {
		if (!finishedInfo())	
			ticketOffice.process(getLatestCustomerInfo());
		else
			ticketOffice.process();		
	}
	
	private void processAtPlatform() {
		updateMovingList();
		if (isToMoveToPlatform())
			platform.process(movingList);
		else
			platform.process();	
	}

	private void makeReport () {
		if (platform.getVolumeOfTraffic() >= customerInfo.size()) {
			StationMaster.analyze(customerInfo).report(Start.REPORT_PATH);
			terminateSimulation();
		}
	}
	
	private void updateMovingList() {
		if (isPassTime())
			movingList = ticketOffice.getMovingList();	
	}

	private boolean isToMoveToPlatform() {
		if (movingList == null)
			this.isToMoveToPlatform = false;
		else if (movingList.size() > 0)
			this.isToMoveToPlatform = true;
		
		return this.isToMoveToPlatform;
	}

	private boolean finishedInfo() {
		if (!finishedInfo && departedCustomer>=50)
			finishedInfo = true;
		return finishedInfo;
	}

	private void terminateSimulation() {
		Start.FLAG = true;
	}
	
	private List<Customer> getLatestCustomerInfo() {
		List<Customer> subList = new ArrayList<Customer>();
		for (Customer customer : customerInfo)
			if (customer.getArrivalTimeAtTicketOffice() == Start.PRESENT_TIME)
				subList.add(customer);
		return subList;		
	}
	
	
	// time
	private boolean isPassTime() {
		return (Start.PRESENT_TIME > getFinalUpdateTime());
	}
	private int getFinalUpdateTime() {
		return finalUpdateTime;
	}
//	private void updateTime() {
//		finalUpdateTime = Start.PRESENT_TIME;
//	}
	

	
	// ...Test.class
	List<Customer> getCustomersList () {
		return customerInfo;
	}List<Customer> getWaitingLineList () {
		return ticketOffice.getWaitingLine();
	}


}
