package element;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class WaitingLine {
	private List<Customer> waitingLine = new ArrayList<Customer>();
	private int finalUpdateTime = 0;
	////// ������� ���
//	private boolean limitedMovement = false;
//	private int movementLimitNumber = 0;
	
//	public WaitingLine () {}
//	public WaitingLine (int movementLimitNumber) {
//		setMovementLimitNumber(movementLimitNumber);
//	}
	
	public void init() {
		waitingLine = new ArrayList<Customer>();
	}
	
	// limited
//	private void setMovementLimitNumber (int movementLimitNumber) {
//		this.limitedMovement = true;
//		this.movementLimitNumber = movementLimitNumber;
//	}
//	private boolean isLimitedMovement () {
//		return limitedMovement;
//	}
//	private int getMovementLimitNumber () {
//		return movementLimitNumber;
//	}
	
	
	//gettter, setter
	public void putCustomer(List<Customer> customers) {
		waitingLine.addAll(customers);
	}
	
	
	
	
	public List<Customer> getCustomer() {
//		System.out.println ("size: " + waitingLine.size());
		return getCustomer(this.waitingLine.size());
	}
	public List<Customer> getCustomer (int number) {
//		System.out.println (waitingLine.size());
		// ���� �ο��� �ִ��� Ȯ��.
//		if (!isLimitedMovement()) {
//			if (number > getMovementLimitNumber())
//				number = getMovementLimitNumber();
//		}
//		// ���� ���� ��ǥ�� ������ ����ο����� ���ٰ� �ϴ��� ������ ���� �ʵ��� ��ȣ
		if (number > waitingLine.size())
			number = waitingLine.size();
		
		
		List<Customer> movementList = new ArrayList<Customer>();
		for (int i=0; i<number; i++)
			movementList.add(waitingLine.remove(0));
		
		return movementList;		
	}
	
	
	
	
	// time
	public int getFinalUpdateTime() {
		return finalUpdateTime;
	}
	public void updateTime(int presentTime) {
		if (presentTime > getFinalUpdateTime()) {
			setUpdateExpectedTimeOfTicketing(presentTime-getFinalUpdateTime());
			setFinalUpdateTime(presentTime);		
		}
	}
	private void setFinalUpdateTime(int presentTime) {
		finalUpdateTime = presentTime;
	}
	private void setUpdateExpectedTimeOfTicketing(int supplementaryTime) {
		for (Customer customer : waitingLine)  // �߰��ð��� ������ �������� �߰��ϵ�, ����ð��� �߰��� ������ �н�
				customer.updateExpectedFinishTimeOfTicketing (supplementaryTime);
	}
	
	public void sortLine() {
		Collections.sort(waitingLine);
	}
	
	
	
	// ...Test.class
	int size() {
		return waitingLine.size();
	}
	List<Customer> getList() {
		return waitingLine;
	}



}
