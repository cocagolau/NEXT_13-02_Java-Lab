package map;

import java.util.ArrayList;
import java.util.List;

import simulation.Start;
import utility.Parser;

import map.TrainMap;
import junit.framework.TestCase;

public class TrainMapTest extends TestCase{
	
	Region.Name[] regionList = {Region.Name.Seoul, Region.Name.Asan, Region.Name.Chuncheon, Region.Name.Deajeon, Region.Name.Wonju, Region.Name.Gwangju, Region.Name.Kyungju};
	List<Edge> edges;
	TrainMap tMap;
	List<Region> regions;
	//
	//
	
	
	public void testCreateMap() {

		
	}

	
//	public void setUp() {
//		createEdges();
//		tMap = TrainMap.create(regionList, edges);
//	}
//	
//	private void createEdges() {
//		edges = new ArrayList<Edge>();
//		
//		edges.add(Edge.create(Region.Name.Seoul, Region.Name.Asan, 20));
//		edges.add(Edge.create(Region.Name.Seoul, Region.Name.Deajeon, 29));
//		edges.add(Edge.create(Region.Name.Seoul, Region.Name.Wonju, 22));
//		edges.add(Edge.create(Region.Name.Seoul, Region.Name.Chuncheon, 16));
//		
//		
//		edges.add(Edge.create(Region.Name.Chuncheon, Region.Name.Wonju, 28));
//		edges.add(Edge.create(Region.Name.Chuncheon, Region.Name.Kyungju, 31));
//		
//		edges.add(Edge.create(Region.Name.Wonju, Region.Name.Kyungju, 32));
//		edges.add(Edge.create(Region.Name.Wonju, Region.Name.Deajeon, 23));
//		
//		edges.add(Edge.create(Region.Name.Deajeon, Region.Name.Kyungju, 15));
//		edges.add(Edge.create(Region.Name.Deajeon, Region.Name.Gwangju, 12));
//		edges.add(Edge.create(Region.Name.Deajeon, Region.Name.Asan, 35));
//		
//		edges.add(Edge.create(Region.Name.Asan, Region.Name.Gwangju, 25));
//		
//		edges.add(Edge.create(Region.Name.Kyungju, Region.Name.Gwangju, 18));		
//	}
//
//	public void testGetRegionList() {
//		assertEquals (7, tMap.getRegionList().size());
//	}
//	
//	public void testGetEdgeList() {
//		assertEquals (13, tMap.getEdgeList().size());
//	}
//	
//	
//	public void testGetRegion () {
//		for (Region.Name name : regionList)
//			assertEquals (name, tMap.getRegion(name).getName());
//	}
//	
//	public void testAddEdge() {
//		int[] numberOfEdge = new int[] {4, 3, 3, 5, 4, 3, 4};
//		regions = tMap.getRegionList();
//		int i=0;
//		for (Region region : regions)
//			assertEquals (numberOfEdge[i++], region.getEdgeList().size());
//	}
	
	
}
