package element;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import map.Region;

import simulation.Start;


import element.Customer;

import junit.framework.TestCase;

public class WaitingLineTest extends TestCase{

	WaitingLine waitingLine;
	List<Customer> customers1, customers2, customers3;
	List<Customer> allCustomers;
	static final int NUMBER_OF_STAFF = 3;
	
	public void setUp() {
		waitingLine = new WaitingLine(WaitingLineTest.NUMBER_OF_STAFF);
		allCustomers = new ArrayList<Customer>();
		customers1 = new ArrayList<Customer>();
		customers2 = new ArrayList<Customer>();
		customers3 = new ArrayList<Customer>();
		
		// start
		customers1.add(Customer.create( 1, "customer1", 0, 1, Region.Name.Seoul, Region.Name.Deajeon, 2)); // 1
		customers1.add(Customer.create( 2, "customer2", 0, 2, Region.Name.Seoul, Region.Name.Deajeon, 2)); // 2
		customers1.add(Customer.create( 3, "customer2", 0, 3, Region.Name.Seoul, Region.Name.Deajeon, 2)); // 3
		customers1.add(Customer.create( 4, "customer2", 0, 1, Region.Name.Seoul, Region.Name.Deajeon, 2)); // 1
		
		// after 1min 
		customers2.add(Customer.create( 5, "customer2", 1, 1, Region.Name.Seoul, Region.Name.Deajeon, 2)); // 2
		
		// after 2min		
		customers3.add(Customer.create( 6, "customer2", 2, 6, Region.Name.Seoul, Region.Name.Deajeon, 2)); // 8
		customers3.add(Customer.create( 7, "customer2", 2, 7, Region.Name.Seoul, Region.Name.Deajeon, 2)); // 9
		customers3.add(Customer.create( 8, "customer2", 2, 3, Region.Name.Seoul, Region.Name.Deajeon, 2)); // 5
		customers3.add(Customer.create( 9, "customer2", 2, 1, Region.Name.Seoul, Region.Name.Deajeon, 2)); // 3
		customers3.add(Customer.create(10, "customer2", 2, 1, Region.Name.Seoul, Region.Name.Deajeon, 2)); // 3
	}

	public void testPutInLine() {
		waitingLine.putCustomer(customers1);
		waitingLine.sortLine();
		assertEquals (4, waitingLine.size());
		
		waitingLine.putCustomer(customers2);
		waitingLine.sortLine();
		assertEquals (5, waitingLine.size());
	}
	
	public void testSortList() {
		List<Customer> listOfWaitingLine;
		
		allCustomers.addAll(customers1);
		allCustomers.addAll(customers2);
		allCustomers.addAll(customers3);
		Collections.sort(allCustomers);
		
		waitingLine.putCustomer(customers1);
		waitingLine.sortLine();
		waitingLine.putCustomer(customers2);
		waitingLine.sortLine();
		waitingLine.putCustomer(customers3);
		waitingLine.sortLine();
		
		listOfWaitingLine = waitingLine.getList();
		for (int i=0; i<listOfWaitingLine.size(); i++) {
//			System.out.println (allCustomers.get(i).getId());
			assertEquals (allCustomers.get(i), listOfWaitingLine.get(i));
		}
	}
		
	public void testGetInLine() {
		Start.PRESENT_TIME = 0;
		List<Customer> goTicketing;
		
		// presentTime = 0;
		waitingLine.putCustomer(customers1);  // 0�п� ����, �������ڸ��� ���� �߰�
		waitingLine.sortLine();
		
		goTicketing = waitingLine.getCustomer(3);  // ���� �߰����ڸ��� staff�� ��ŭ ticketing, �ִ� 3������
		assertEquals (3, goTicketing.size());
		
		assertEquals (customers1.get(0), goTicketing.get(0));
		assertEquals (1, goTicketing.get(0).getExpectedFinishTimeOfTicketing());
		
		assertEquals (customers1.get(3), goTicketing.get(1));
		assertEquals (1, goTicketing.get(1).getExpectedFinishTimeOfTicketing());
		
		assertEquals (customers1.get(1), goTicketing.get(2));
		assertEquals (2, goTicketing.get(2).getExpectedFinishTimeOfTicketing());

	
		// after a minute
		Start.PRESENT_TIME++;
		waitingLine.updateTime(Start.PRESENT_TIME);		
		waitingLine.putCustomer(customers2);  // 1�п� ����
		waitingLine.sortLine();
		
		goTicketing = waitingLine.getCustomer(2);
		assertEquals (2, goTicketing.size());
		
		assertEquals (customers2.get(0), goTicketing.get(0));
		assertEquals (2, goTicketing.get(0).getExpectedFinishTimeOfTicketing());
		
		assertEquals (customers1.get(2), goTicketing.get(1));
		assertEquals (4, goTicketing.get(1).getExpectedFinishTimeOfTicketing());
		
		
	
		// after a minute
		Start.PRESENT_TIME++;
		waitingLine.updateTime(Start.PRESENT_TIME);
		waitingLine.putCustomer(customers3);  // 2�п� ����
		waitingLine.sortLine();
		
		goTicketing = waitingLine.getCustomer(3);
		assertEquals (3, goTicketing.size());
		
		assertEquals (customers3.get(3), goTicketing.get(0));
		assertEquals (3, goTicketing.get(0).getExpectedFinishTimeOfTicketing());
		
		assertEquals (customers3.get(4), goTicketing.get(1));
		assertEquals (3, goTicketing.get(1).getExpectedFinishTimeOfTicketing());
		
		assertEquals (customers3.get(2), goTicketing.get(2));
		assertEquals (5, goTicketing.get(2).getExpectedFinishTimeOfTicketing());
		
		
		
		// after a minute
		Start.PRESENT_TIME++;
		waitingLine.updateTime(Start.PRESENT_TIME);
		
		goTicketing = waitingLine.getCustomer(3); // ���� �ο��� ��ǥ�� ������ ������ ���ٰ� �ϴ��� ��ȣ��
		assertEquals (2, goTicketing.size());
		
		assertEquals (customers3.get(0), goTicketing.get(0));
		assertEquals (9, goTicketing.get(0).getExpectedFinishTimeOfTicketing());
		
		assertEquals (customers3.get(1), goTicketing.get(1));
		assertEquals (10, goTicketing.get(1).getExpectedFinishTimeOfTicketing());
	}

}
