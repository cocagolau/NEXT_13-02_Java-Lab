package piece;

import java.util.List;

public class Queen extends Piece{
	private Move[] moves = {Move.NW, Move.N, Move.NE, Move.W, Move.E, Move.SW, Move.S, Move.SE};
	
	//constructor
	private Queen (Piece.Color color) {
		super (Piece.Type.QUEEN, color);
	}
	
	public static Queen white() {
		return new Queen (Piece.Color.WHITE);
	}
	
	public static Queen black() {
		return new Queen (Piece.Color.BLACK);
	}
	
	@Override
	public List<String> getPossibleMoves() {
		return getPossibleMoves(moves);
	}
}
