package piece;

import static board.Position.doubleMove;
import java.util.List;

public class Knight extends Piece{
	private Move[] moves = {Move.NW, Move.SW, Move.NE, Move.SE};
	
	//constructor
	private Knight (Piece.Color color) {
		super (Piece.Type.KNIGHT, color);
	}
	
	public static Knight white() {
		return new Knight (Piece.Color.WHITE);
	}
	
	public static Knight black() {
		return new Knight (Piece.Color.BLACK);
	}
	
	@Override
	public List<String> getPossibleMoves() {
		return getPossibleMoves(moves);
	}
	
	@Override
	protected void irregularMoves(int x, int y, Move move) {	
		putMovement (x + doubleMove(move.getX()), y + move.getY());
		putMovement (x + move.getX(), y + doubleMove(move.getY()));
	}

}
