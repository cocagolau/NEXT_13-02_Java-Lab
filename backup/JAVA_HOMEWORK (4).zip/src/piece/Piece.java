package piece;

import static util.Util.NEWSPACE;

import java.util.ArrayList;
import java.util.List;

import board.Board;
import board.Position;

public abstract class Piece implements Comparable<Piece> {
	
	public enum Color { NONE, WHITE, BLACK; }
	
	public enum Type {
		NONE(0.0, NEWSPACE), PAWN(1.0, 'p'), KNIGHT(2.5, 'n'), BISHOP(3.0, 'b'), ROOK(5.0, 'r'), QUEEN(9.0, 'q'), KING(10.0, 'k');
		private double points;
		private char representation;
		
		Type (double points, char representation) {
			this.points = points;
			this.representation = representation;
		}
		public double getPoints () {
			return this.points;
		}
		public char getRepresentation() {
			return this.representation;
		}
	}
	
	public enum Move {
		NW(-1,1), N(0,1), NE(1,1), W(-1,0), E(1,0), SW(-1,-1), S(0,-1), SE(1,-1);
		private int x;
		private int y;
		
		Move (int x, int y) {
			this.x = x;
			this.y = y;
		}
		public int getX() {
			return x;
		}
		public int getY() {
			return y;
		}
	}
	
	protected List<String> possibleMoves;
	protected Position pos;
	protected Piece.Type type;
	protected Piece.Color color;
	
	
	// private constructor
	protected Piece(Piece.Type type, Piece.Color color) {
		this.type = type;
		this.color = color;
	}
	
	@Override
	public int compareTo(Piece that) {
		double x = this.getType().getPoints();
		double y = that.getType().getPoints();
	
		if      (x>y)  return -1;
		else if (x==y) return 0;
		else		   return 1;
	}
	
	// instance method
	////
	public boolean isWhite() {
		return this.color.equals(Piece.Color.WHITE);
	}	
	public boolean isBlack() {
		return this.color.equals(Piece.Color.BLACK);
	}
	
	////
	public Piece.Color getColor() {
		return this.color;
	}
	public Piece.Type getType() {
		return this.type;
	}
	public double getPoints() {
		return this.getType().getPoints();
	}
	public char getRepresentation() {
		char type = this.getType().getRepresentation();
		if (this.getColor() == Piece.Color.WHITE)
			return type;
		else
			return Character.toUpperCase(type);
	}
	
	////
	public int getX () {
		return pos.getX();
	}
	public int getY () {
		return pos.getY();
	}
	public String getPosition() {
		return pos.getCode();
	}
	public void setPosition(String code) {
		pos = new Position(code);
	}

	
	// moves
	public abstract List<String> getPossibleMoves ();
	protected List<String> getPossibleMoves (Move[] moves) {
		Class thisClass = this.getClass();
		possibleMoves = new ArrayList<String>();

		for (int i=0; i<moves.length; i++) {
				 if (thisClass == piece.King.class  || thisClass == piece.Knight.class || thisClass == piece.Pawn.class)
				irregularMoves (getX(), getY(), moves[i]);
				 
			else if (thisClass == piece.Queen.class || thisClass == piece.Bishop.class || thisClass == piece.Rook.class)
				  regularMoves (getX(), getY(), moves[i]);
		}
		return possibleMoves;
	}

	protected void irregularMoves (int x, int y, Move move) {};
	private   void   regularMoves (int x, int y, Move move) {	
		int newX = x + move.getX();
		int newY = y + move.getY();
		// end condition
		if (newX < 0 || newX >= Board.BOARD_LINES) return;
		if (newY < 0 || newY >= Board.BOARD_LINES) return;
	
		putMovement (newX, newY);
		//recursive call
		regularMoves (newX, newY, move);
	}
	
	protected void putMovement (int x, int y) {
		pickMovementOut (Position.getCode(x, y));
	}
	
	private void pickMovementOut (String code) {
		if (code != null)
			possibleMoves.add(code);
	}

}
