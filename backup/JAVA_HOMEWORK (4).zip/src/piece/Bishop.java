package piece;

import java.util.List;


public class Bishop extends Piece{
	private Move[] moves = {Move.NW, Move.NE, Move.SW, Move.SE};
	
	//constructor
	private Bishop (Piece.Color color) {
		super (Piece.Type.BISHOP, color);
	}
	
	public static Bishop white() {
		return new Bishop (Piece.Color.WHITE);
	}
	
	public static Bishop black() {
		return new Bishop (Piece.Color.BLACK);
	}

	@Override
	public List<String> getPossibleMoves() {
		return getPossibleMoves(moves);
	}
}
