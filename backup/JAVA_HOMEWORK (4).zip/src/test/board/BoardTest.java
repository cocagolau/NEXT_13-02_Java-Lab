package test.board;

import static util.Util.*;
import java.util.List;

import board.Board;

import piece.Bishop;
import piece.King;
import piece.Knight;
import piece.Pawn;
import piece.Piece;
import piece.Queen;
import piece.Rook;
import junit.framework.TestCase;

public class BoardTest extends TestCase {
	
	Board board;
	
	public void setUp () {
		board = new Board();
		board.initialize();
	}
	
	public void testCreate() {
		Piece p1 = King.black();
		Piece p2 = Rook.black();
		Piece p3 = King.white();
		
		board.putPiece("b3", p1);
		board.putPiece("b4", p2);
		board.putPiece("c5", p3);
		
		assertEquals ("b3", p1.getPosition());
		assertEquals ("b4", p2.getPosition());
		assertEquals ("c5", p3.getPosition());	
	}
	
	
	public void testBoard() {
		String testP = "pppppppp";
		String testCapitalP = "PPPPPPPP";
		String testBlank = "........";
		
		for (int i=0; i<Board.BOARD_LINES; i++) {
			board.getLine(0).setPieceInLine(i,Pawn.white());
			board.getLine(1).setPieceInLine(i,Pawn.white());
			board.getLine(6).setPieceInLine(i,Pawn.black());
			board.getLine(7).setPieceInLine(i,Pawn.black());
		}
		
		String blankRank = appendNewLine (testBlank);
		assertEquals (appendNewLine(testP) +
					  appendNewLine(testP) +
					  blankRank + 
					  blankRank + 
					  blankRank + 
					  blankRank + 
					  appendNewLine(testCapitalP) +
					  appendNewLine(testCapitalP), board.printBoard());
		
	}
	
	
	public void testCount () {
		boardInit1();
//		System.out.println (board.printBoard());
		assertEquals (3, board.getCount(Piece.Type.PAWN, Piece.Color.BLACK));
	}
	
	
	public void testScore () {
		boardInit1();
		assertEquals (20.0, board.getScore (Piece.Color.BLACK));
		assertEquals (19.5, board.getScore (Piece.Color.WHITE));
		
	}
	
	public void testSort () {
		boardInit1();
		List<Piece> whitePieceList, blackPieceList;
		whitePieceList = board.getSortedList(Piece.Color.WHITE);
		blackPieceList = board.getSortedList(Piece.Color.BLACK);
		
		// black
		assertEquals ('K', blackPieceList.get(0).getRepresentation());
		assertEquals ('Q', blackPieceList.get(1).getRepresentation());
		assertEquals ('R', blackPieceList.get(2).getRepresentation());
		assertEquals ('B', blackPieceList.get(3).getRepresentation());
		assertEquals ('P', blackPieceList.get(4).getRepresentation());
		assertEquals ('P', blackPieceList.get(5).getRepresentation());
		assertEquals ('P', blackPieceList.get(6).getRepresentation());
		
		// white
		assertEquals ('k', whitePieceList.get(0).getRepresentation());
		assertEquals ('q', whitePieceList.get(1).getRepresentation());
		assertEquals ('r', whitePieceList.get(2).getRepresentation());
		assertEquals ('n', whitePieceList.get(3).getRepresentation());
		assertEquals ('p', whitePieceList.get(4).getRepresentation());
		assertEquals ('p', whitePieceList.get(5).getRepresentation());
		assertEquals ('p', whitePieceList.get(6).getRepresentation());
		assertEquals ('p', whitePieceList.get(7).getRepresentation());
		
		
	}
	
	
	public void boardInit1 () {
		//black
		board.getLine(0).setPieceInLine(1, King.black());
		board.getLine(0).setPieceInLine(2, Rook.black());
		board.getLine(1).setPieceInLine(0, Pawn.black());
		board.getLine(1).setPieceInLine(2, Pawn.black());
		board.getLine(1).setPieceInLine(3, Bishop.black());
		board.getLine(2).setPieceInLine(1, Pawn.black());
		board.getLine(2).setPieceInLine(4, Queen.black());
		//white
		board.getLine(4).setPieceInLine(5, Knight.white());
		board.getLine(4).setPieceInLine(6, Queen.white());
		board.getLine(5).setPieceInLine(5, Pawn.white());
		board.getLine(5).setPieceInLine(7, Pawn.white());
		board.getLine(6).setPieceInLine(5, Pawn.white());
		board.getLine(6).setPieceInLine(6, Pawn.white());
		board.getLine(7).setPieceInLine(4, Rook.white());
		board.getLine(7).setPieceInLine(5, King.white());
	}

}
















