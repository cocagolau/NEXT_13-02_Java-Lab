package test.piece;

import piece.Bishop;
import piece.Piece;

public class BishopTest extends PieceTest {
	
	public void testPiece() {
		
		Piece.Type type = Piece.Type.BISHOP;
		Piece whitePiece = Bishop.white();
		Piece blackPiece = Bishop.black();
		
		verifyCreation (whitePiece, blackPiece, type, type.getRepresentation(), type.getPoints());
		
//		whitePiece.addCoordi(4, 3);
////		System.out.println (printPossibleMoves(whitePiece.getPossibleMoves()));
//		assertEquals ("PossibleMoves : e4 f5 g6 e4 d5 c6 b7 e4 d3 c2 e4 f3 g2", printPossibleMoves(whitePiece.getPossibleMoves()));
//		
//		blackPiece.addCoordi(3, 5);
////		System.out.println (printPossibleMoves(blackPiece.getPossibleMoves()));
//		assertEquals ("PossibleMoves : d6 e7 d6 c7 d6 c5 b4 d6 e5 f4 g3", printPossibleMoves(blackPiece.getPossibleMoves()));
	}

}
