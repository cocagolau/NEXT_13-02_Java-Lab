package test.piece;

import piece.Pawn;
import piece.Piece;

public class PawnTest extends PieceTest {
	
	public void testPiece() {
		
		Piece.Type type = Piece.Type.PAWN;
		Piece whitePiece = Pawn.white();
		Piece blackPiece = Pawn.black();
		
		verifyCreation (whitePiece, blackPiece, type, type.getRepresentation(), type.getPoints());
		
	}

}
