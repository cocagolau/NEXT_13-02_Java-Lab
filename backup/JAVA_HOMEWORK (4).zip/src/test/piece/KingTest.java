package test.piece;

import piece.King;
import piece.Piece;

public class KingTest extends PieceTest {
	
	public void testPiece() {
//		double points = 10.0;
//		char representation = 'k';
		
		Piece.Type type = Piece.Type.KING;
		Piece whitePiece = King.white();
		Piece blackPiece = King.black();

		verifyCreation (whitePiece, blackPiece, type, type.getRepresentation(), type.getPoints());
//		assertEquals (points, whitePiece.getPoints());
//		assertEquals (points, blackPiece.getPoints());
//		
//		assertEquals (representation, whitePiece.getRepresentation());
//		assertEquals (Character.toUpperCase(representation), blackPiece.getRepresentation());

	}

}

