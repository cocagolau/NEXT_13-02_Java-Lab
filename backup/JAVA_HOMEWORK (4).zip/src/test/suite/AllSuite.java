package test.suite;

import junit.framework.TestSuite;

public class AllSuite extends TestSuite {
	
	public static TestSuite suite() {
		
		TestSuite suite = new TestSuite();
		
		suite.addTest(test.board.AllTests.suite());
		suite.addTest(test.piece.AllTests.suite());
		suite.addTest(test.util.AllTests.suite());
		
		return suite;
	}

}
