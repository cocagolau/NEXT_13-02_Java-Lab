package test.util;

import util.Util;
import junit.framework.TestCase;

public class UtilTest extends TestCase {
	
	public void testStringUtil () {
		
		String testString = "qqqqqqqq";
		
		assertEquals (testString+'\n', Util.appendNewLine(testString));
		assertEquals (testString+'\t', Util.appendNewTap(testString));
		assertEquals (testString+' ', Util.appendNewSpace(testString));
		
	}

}
