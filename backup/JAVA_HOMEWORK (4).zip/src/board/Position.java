package board;


public class Position {

	private static final int code1stValue = 'a';
	private static final int code2ndValue = '1';
	
	// instance variable
	private int x;
	private int y;

	// constructor
	public Position(int x, int y) {
		this.x = x;
		this.y = y;
	}
	public Position(String code) {
		this.x = transfer1stCode(code.charAt(0));
		this.y = transfer2ndCode(code.charAt(1));
	}
	
	// class method
	public static String getCode (int x, int y) {
		if (x<0 || x>=Board.BOARD_LINES) return null;
		if (y<0 || y>=Board.BOARD_LINES) return null;
		
		int frontCodeValue = x + Position.code1stValue;
		int rearCodeValue  = y + Position.code2ndValue;
		return Character.toString((char)frontCodeValue)
			 + Character.toString((char)rearCodeValue );
	}
	
	public static int doubleMove (int num) {		
		return num*2;
	}
	
	
	// instance method
	public int getX() {
		return this.x;
	}
	public int getY() {
		return this.y;
	}
	public String getCode () {	
		return getCode(x,y);
	}	
	
	
	//// interpreter
	private int transfer1stCode (char codeValue) {
		return ((int)codeValue - Position.code1stValue);
	}
	private int transfer2ndCode (char codeValue) {
		return ((int)codeValue - Position.code2ndValue);
	}

}
