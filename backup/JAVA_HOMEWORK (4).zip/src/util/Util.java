package util;


public class Util {
//	public static final String NEWLINE = System.getProperty("line.separator");
	public static final char NEWLINE = '\n';
	public static final char NEWTAP = '\t';
	public static final char NEWSPACE = ' ';
	public static final char NEWPOINT = '.';	
	
	private Util () {}
	
	public static String appendNewLine (String string) {
		return string + Util.NEWLINE; 
	}

	public static String appendNewTap(String string) {
		return string + Util.NEWTAP; 
	}
	
	public static String appendNewSpace(String string) {
		return string + Util.NEWSPACE; 
	}
	
}
