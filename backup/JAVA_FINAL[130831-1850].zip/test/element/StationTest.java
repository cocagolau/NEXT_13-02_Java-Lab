package element;


import simulation.Start;
import junit.framework.TestCase;

public class StationTest extends TestCase{

	Station station;
	boolean flag = false;
	
	public void setUp () {
		station = Station.create(Start.CUSTOMER_INFO_PATH);
	}
//	public void testHasCustomersInWaitingLine() {
	
	public void test1() {
	}
	
	
	// change private
//	public void testLineCustomersUp() {
//		Start.PRESENT_TIME = 0;
//		
//		while (!flag) {
//			station.lineCustomersUp();
//			if (++Start.PRESENT_TIME > 42) flag = true;
//		}
//		assertEquals (50, station.getWaitingLineList().size());
//				
//	}
	
	
//	public void testGetArrivalCustomer() {
//		List<Customer> subList;
//		
//		station = Station.create(Start.CUSTOMER_INFO_PATH);
//		
////		station.executeSimulation();
//////		station.checkStateOfProgress();
////		assertEquals (5, station.getWaitingLineSize());
////		assertEquals (3, station.getTicketOfficeSize());
////		assertEquals (3, station.getNumberOfWorkingStaff());
////		assertEquals (0, station.getNumberOfRestingStaff());
//		
//		
//	}
}
