package simulation;

import java.io.File;

import element.Station;

public class Start {

	public static final String CUSTOMER_INFO_PATH = "final_data" + File.separator + "customerInfo.txt";
	public static final String TRAIN_MAP_PATH = "final_data" + File.separator + "trainMap.txt";
	public static final String TEST_REPORT_PATH = "final_data" + File.separator + "testReport.txt";
	public static final String REPORT_PATH = "final_data" + File.separator + "report.txt";
	
	
	public static final int TRAIN_ALLOCATION_TIME = 5;
	public static final int NUMBER_OF_STAFF = 3;
	
	public static boolean FLAG = false;
	public static int PRESENT_TIME = 0;
	
	
	public static void main (String[] args) {
		Station station = Station.create(Start.CUSTOMER_INFO_PATH);
		while (!Start.FLAG) {
			station.executeSimulation();
			Start.PRESENT_TIME++;
		}
		System.out.println("Station Simulation Complete");

	}
}