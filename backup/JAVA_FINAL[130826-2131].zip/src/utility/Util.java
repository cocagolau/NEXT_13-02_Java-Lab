package utility;

import map.Region;

public class Util {

	public static Region.Name Region(String regionName) {
	
		if (regionName.equals("Seoul"))
			return Region.Name.Seoul;
		else if (regionName.equals("Asan"))
			return Region.Name.Asan;
		else if (regionName.equals("Chuncheon"))
			return Region.Name.Chuncheon;
		else if (regionName.equals("Deajeon"))
			return Region.Name.Deajeon;
		else if (regionName.equals("Wonju"))
			return Region.Name.Wonju;
		else if (regionName.equals("Gwangju"))
			return Region.Name.Gwangju;
		else if (regionName.equals("Kyungju"))
			return Region.Name.Kyungju;
		else
			return null; // ���ī��?
	}
	
	public static String Region(Region.Name region) {
		
		if (region.equals(Region.Name.Seoul))
			return "Seoul";
		else if (region.equals(Region.Name.Asan))
			return "Asan";
		else if (region.equals(Region.Name.Chuncheon))
			return "Chuncheon";
		else if (region.equals(Region.Name.Deajeon))
			return "Deajeon";
		else if (region.equals(Region.Name.Wonju))
			return "Wonju";
		else if (region.equals(Region.Name.Gwangju))
			return "Gwangju";
		else if (region.equals(Region.Name.Kyungju))
			return "Kyungju";
		else
			return null; // ���ī��?
	}

}
