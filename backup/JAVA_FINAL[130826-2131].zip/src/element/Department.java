package element;

import java.util.List;
import utility.Clock;

// quota�� ���� ���� �޼ҵ带 ����� ���� ������.
public abstract class Department {
	protected final int QUOTA;
	protected WaitingLine waitingLine = new WaitingLine();
	protected Clock clock = new Clock();
	
	
	// constructor
	public Department() {
		this.QUOTA = -1; // unlimited Quota
	}
	public Department(int quota) {
		this.QUOTA = quota;		
	}


	// waitingLine
	public void putInLine(List<Customer> customers) {
		waitingLine.put(customers);
	}
	protected List<Customer> getInLine (int number) {
		return waitingLine.get(number);
	}
	
	// process
	public void process(List<Customer> customers) {
		putInLine(customers);
		process();
	}
	public void process() {
		if (clock.isPassTime()) {
			processingRegardOfTimePassed();
			clock.updateTime();
		}
		processingRegardlessOfTime();
		
	}
	protected abstract void processingRegardOfTimePassed();
	protected abstract void processingRegardlessOfTime();
	

	// test method
	List<Customer> getWaitingLine() {
		return waitingLine.getList();
	}


}
