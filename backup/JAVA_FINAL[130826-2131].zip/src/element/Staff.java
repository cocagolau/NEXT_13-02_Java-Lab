package element;

import utility.Dijkstra;
import map.TrainMap;


public class Staff {

	private Dijkstra dijkstra;
	private Customer customer;
	private int time = 0;
	
	public Staff(Customer customer, TrainMap tMap) {
		this.customer = customer;
		dijkstra = new Dijkstra(tMap, customer.getDepartureStation());
	}

	public void setTime() {
		this.time ++; 
	}
	public void setTravelTime(int travelTime) {
		customer.setTravelTime(travelTime);
	}
	
	public int getTime() {
		return time;
	}

	public boolean isWorking() {
		if (time < customer.getTimeRequiredForTicketing()) {
			return true;
		}
		return false;
	}

	public Customer getCustomer() {
		return customer;
	}

}
