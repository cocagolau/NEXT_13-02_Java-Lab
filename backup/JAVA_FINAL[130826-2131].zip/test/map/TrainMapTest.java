package map;


import element.Customer;
import element.Staff;
import simulation.Start;
import utility.Parser;

import map.TrainMap;
import junit.framework.TestCase;

public class TrainMapTest extends TestCase{
	
	TrainMap tMap;
	MapParser mapParser;
	Region.Name name = Region.Name.Seoul;
	
	Staff staff;
	Customer customer1, customer2, customer3, customer4, customer5, customer6, customer7;
	
	public void setUp() {
		mapParser = new MapParser(Start.TRAIN_MAP_PATH, Parser.Separator.TAP);
		tMap = TrainMap.create(mapParser.getToRegionList(), mapParser.getCreations());
		
		customer1 = Customer.create(1, "customer1", 1, 1, Region.Name.Seoul, Region.Name.Deajeon);
		customer2 = Customer.create(1, "customer1", 1, 1, Region.Name.Asan, Region.Name.Deajeon);
		customer3 = Customer.create(1, "customer1", 1, 1, Region.Name.Chuncheon, Region.Name.Deajeon);
		customer4 = Customer.create(1, "customer1", 1, 1, Region.Name.Deajeon, Region.Name.Seoul);
		customer5 = Customer.create(1, "customer1", 1, 1, Region.Name.Wonju, Region.Name.Deajeon);
		customer6 = Customer.create(1, "customer1", 1, 1, Region.Name.Gwangju, Region.Name.Deajeon);
		customer7 = Customer.create(1, "customer1", 1, 1, Region.Name.Kyungju, Region.Name.Deajeon);
		staff = new Staff(customer1, tMap);
	}
	
	public void testGetShortestDstance() {
		assertEquals (20, tMap.getShortestDistance(Region.Name.Seoul, Region.Name.Asan));
		assertEquals (16, tMap.getShortestDistance(Region.Name.Seoul, Region.Name.Chuncheon));
		assertEquals (29, tMap.getShortestDistance(Region.Name.Seoul, Region.Name.Deajeon));
		assertEquals (22, tMap.getShortestDistance(Region.Name.Seoul, Region.Name.Wonju));
		assertEquals (41, tMap.getShortestDistance(Region.Name.Seoul, Region.Name.Gwangju));
		assertEquals (44, tMap.getShortestDistance(Region.Name.Seoul, Region.Name.Kyungju));
		
		staff = new Staff(customer2, tMap);
		assertEquals (20, tMap.getShortestDistance(Region.Name.Asan, Region.Name.Seoul));
		assertEquals (36, tMap.getShortestDistance(Region.Name.Asan, Region.Name.Chuncheon));
		assertEquals (35, tMap.getShortestDistance(Region.Name.Asan, Region.Name.Deajeon));
		assertEquals (42, tMap.getShortestDistance(Region.Name.Asan, Region.Name.Wonju));
		assertEquals (25, tMap.getShortestDistance(Region.Name.Asan, Region.Name.Gwangju));
		assertEquals (43, tMap.getShortestDistance(Region.Name.Asan, Region.Name.Kyungju));
		
		staff = new Staff(customer3, tMap);
		assertEquals (16, tMap.getShortestDistance(Region.Name.Chuncheon, Region.Name.Seoul));
		assertEquals (36, tMap.getShortestDistance(Region.Name.Chuncheon, Region.Name.Asan));
		assertEquals (45, tMap.getShortestDistance(Region.Name.Chuncheon, Region.Name.Deajeon));
		assertEquals (28, tMap.getShortestDistance(Region.Name.Chuncheon, Region.Name.Wonju));
		assertEquals (49, tMap.getShortestDistance(Region.Name.Chuncheon, Region.Name.Gwangju));
		assertEquals (31, tMap.getShortestDistance(Region.Name.Chuncheon, Region.Name.Kyungju));
		
		staff = new Staff(customer4, tMap);
		assertEquals (29, tMap.getShortestDistance(Region.Name.Deajeon, Region.Name.Seoul));
		assertEquals (35, tMap.getShortestDistance(Region.Name.Deajeon, Region.Name.Asan));
		assertEquals (45, tMap.getShortestDistance(Region.Name.Deajeon, Region.Name.Chuncheon));
		assertEquals (23, tMap.getShortestDistance(Region.Name.Deajeon, Region.Name.Wonju));
		assertEquals (12, tMap.getShortestDistance(Region.Name.Deajeon, Region.Name.Gwangju));
		assertEquals (15, tMap.getShortestDistance(Region.Name.Deajeon, Region.Name.Kyungju));
		
		staff = new Staff(customer5, tMap);
		assertEquals (22, tMap.getShortestDistance(Region.Name.Wonju, Region.Name.Seoul));
		assertEquals (42, tMap.getShortestDistance(Region.Name.Wonju, Region.Name.Asan));
		assertEquals (28, tMap.getShortestDistance(Region.Name.Wonju, Region.Name.Chuncheon));
		assertEquals (23, tMap.getShortestDistance(Region.Name.Wonju, Region.Name.Deajeon));
		assertEquals (35, tMap.getShortestDistance(Region.Name.Wonju, Region.Name.Gwangju));
		assertEquals (32, tMap.getShortestDistance(Region.Name.Wonju, Region.Name.Kyungju));
		
		staff = new Staff(customer6, tMap);
		assertEquals (41, tMap.getShortestDistance(Region.Name.Gwangju, Region.Name.Seoul));
		assertEquals (25, tMap.getShortestDistance(Region.Name.Gwangju, Region.Name.Asan));
		assertEquals (49, tMap.getShortestDistance(Region.Name.Gwangju, Region.Name.Chuncheon));
		assertEquals (12, tMap.getShortestDistance(Region.Name.Gwangju, Region.Name.Deajeon));
		assertEquals (35, tMap.getShortestDistance(Region.Name.Gwangju, Region.Name.Wonju));
		assertEquals (18, tMap.getShortestDistance(Region.Name.Gwangju, Region.Name.Kyungju));
		
		staff = new Staff(customer7, tMap);
		assertEquals (44, tMap.getShortestDistance(Region.Name.Kyungju, Region.Name.Seoul));
		assertEquals (43, tMap.getShortestDistance(Region.Name.Kyungju, Region.Name.Asan));
		assertEquals (31, tMap.getShortestDistance(Region.Name.Kyungju, Region.Name.Chuncheon));
		assertEquals (15, tMap.getShortestDistance(Region.Name.Kyungju, Region.Name.Deajeon));
		assertEquals (32, tMap.getShortestDistance(Region.Name.Kyungju, Region.Name.Wonju));
		assertEquals (18, tMap.getShortestDistance(Region.Name.Kyungju, Region.Name.Gwangju));
	}
	
	public void testContatinsKey() {
		assertTrue (tMap.containsKey(tMap.getRegion(Region.Name.Seoul)));
		assertFalse (tMap.containsKey(tMap.getRegion(Region.Name.Wonju)));
	}
	
}
