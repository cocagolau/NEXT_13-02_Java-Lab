package strategy;

import java.util.List;

import element.Customer;
import element.Staff;
import element.WaitingLine;


public class LeastWaiting extends RoutingStrategy {
	
	public LeastWaiting (List<Staff> staffList) {
		super(staffList);
	}
	
	@Override
	public void sendToStaff(WaitingLine waitingLine) {
		setRestingStaffList();
		waitingLine.sortWaitingLine();
		int i=0;
		for (Customer customer : waitingLine.deQueue(getNumberOfRestingStaff())) {
			customer.leaveWaitingLine();
			restingStaffList.get(i++).put(customer);
		}
	}

}
