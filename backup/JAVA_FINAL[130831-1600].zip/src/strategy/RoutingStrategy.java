package strategy;

import java.util.ArrayList;
import java.util.List;

import element.Staff;

import simulation.Start;


public abstract class RoutingStrategy  implements IStrategy{
	
	protected List<Staff> restingStaffList = null;
	protected List<Staff> staffList;
	
	protected RoutingStrategy (List<Staff> staffList) {
		this.staffList = staffList;
	}
	public static RoutingStrategy design (int code, List<Staff> staffList) {
		if (code == 1)
			return new RoundRobbin(staffList);
		else if (code == 2)
			return new Random(staffList);
		else
			return new LeastWaiting(staffList);
	}
	
	protected void setRestingStaffList() {
		restingStaffList = new ArrayList<Staff>();
		for (Staff staff : staffList) {
			if (staff.isResting())
				restingStaffList.add(staff);
		}
	}
	protected int getNumberOfRestingStaff() {
		if (restingStaffList == null) return Start.NUMBER_OF_STAFF;
		return restingStaffList.size();
	}
	

}
