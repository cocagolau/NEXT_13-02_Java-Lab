package utility;


import java.util.List;

import simulation.Start;
import utility.Parser;
import element.Customer;

import junit.framework.TestCase;

public class ParserTest extends TestCase{
	
	Parser parser;
	List<Customer> customers;
//
//	public void setUp() {
//		parser = Parser.analyze(Start.CUSTOMER_INFO_PATH);
//	}
//	
//	public void testCreate() {
//		customers = parser.getCustomerList();
//		assertEquals (50, customers.size());
//	}

}
